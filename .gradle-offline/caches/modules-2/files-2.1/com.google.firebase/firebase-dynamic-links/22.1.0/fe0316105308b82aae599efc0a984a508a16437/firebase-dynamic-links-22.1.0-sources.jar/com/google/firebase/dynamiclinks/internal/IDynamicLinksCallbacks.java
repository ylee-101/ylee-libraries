/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package com.google.firebase.dynamiclinks.internal;
public interface IDynamicLinksCallbacks extends android.os.IInterface
{
  /** Default implementation for IDynamicLinksCallbacks. */
  public static class Default implements com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks
  {
    @Override public void onGetDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.DynamicLinkData dynamicLinksData) throws android.os.RemoteException
    {
    }
    @Override public void onCreateShortDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.ShortDynamicLinkImpl shortDynamicLink) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks interface,
     * generating a proxy if needed.
     */
    public static com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks))) {
        return ((com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks)iin);
      }
      return new com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_onGetDynamicLink:
        {
          com.google.android.gms.common.api.Status _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.google.android.gms.common.api.Status.CREATOR);
          com.google.firebase.dynamiclinks.internal.DynamicLinkData _arg1;
          _arg1 = _Parcel.readTypedObject(data, com.google.firebase.dynamiclinks.internal.DynamicLinkData.CREATOR);
          this.onGetDynamicLink(_arg0, _arg1);
          break;
        }
        case TRANSACTION_onCreateShortDynamicLink:
        {
          com.google.android.gms.common.api.Status _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.google.android.gms.common.api.Status.CREATOR);
          com.google.firebase.dynamiclinks.internal.ShortDynamicLinkImpl _arg1;
          _arg1 = _Parcel.readTypedObject(data, com.google.firebase.dynamiclinks.internal.ShortDynamicLinkImpl.CREATOR);
          this.onCreateShortDynamicLink(_arg0, _arg1);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onGetDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.DynamicLinkData dynamicLinksData) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, status, 0);
          _Parcel.writeTypedObject(_data, dynamicLinksData, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onGetDynamicLink, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void onCreateShortDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.ShortDynamicLinkImpl shortDynamicLink) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, status, 0);
          _Parcel.writeTypedObject(_data, shortDynamicLink, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onCreateShortDynamicLink, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onGetDynamicLink = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_onCreateShortDynamicLink = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  public static final java.lang.String DESCRIPTOR = "com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks";
  public void onGetDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.DynamicLinkData dynamicLinksData) throws android.os.RemoteException;
  public void onCreateShortDynamicLink(com.google.android.gms.common.api.Status status, com.google.firebase.dynamiclinks.internal.ShortDynamicLinkImpl shortDynamicLink) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
