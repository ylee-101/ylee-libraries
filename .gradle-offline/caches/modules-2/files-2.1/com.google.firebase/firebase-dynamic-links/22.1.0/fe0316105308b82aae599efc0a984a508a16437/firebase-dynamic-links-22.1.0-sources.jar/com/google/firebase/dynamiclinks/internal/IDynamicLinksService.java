/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package com.google.firebase.dynamiclinks.internal;
public interface IDynamicLinksService extends android.os.IInterface
{
  /** Default implementation for IDynamicLinksService. */
  public static class Default implements com.google.firebase.dynamiclinks.internal.IDynamicLinksService
  {
    @Override public void getDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, java.lang.String dynamicLink) throws android.os.RemoteException
    {
    }
    @Override public void createShortDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, android.os.Bundle parameters) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.google.firebase.dynamiclinks.internal.IDynamicLinksService
  {
    /** Construct the stub at attach it to the interface. */
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.google.firebase.dynamiclinks.internal.IDynamicLinksService interface,
     * generating a proxy if needed.
     */
    public static com.google.firebase.dynamiclinks.internal.IDynamicLinksService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.google.firebase.dynamiclinks.internal.IDynamicLinksService))) {
        return ((com.google.firebase.dynamiclinks.internal.IDynamicLinksService)iin);
      }
      return new com.google.firebase.dynamiclinks.internal.IDynamicLinksService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      switch (code)
      {
        case INTERFACE_TRANSACTION:
        {
          reply.writeString(descriptor);
          return true;
        }
      }
      switch (code)
      {
        case TRANSACTION_getDynamicLink:
        {
          com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks _arg0;
          _arg0 = com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks.Stub.asInterface(data.readStrongBinder());
          java.lang.String _arg1;
          _arg1 = data.readString();
          this.getDynamicLink(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_createShortDynamicLink:
        {
          com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks _arg0;
          _arg0 = com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks.Stub.asInterface(data.readStrongBinder());
          android.os.Bundle _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          this.createShortDynamicLink(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.google.firebase.dynamiclinks.internal.IDynamicLinksService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void getDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, java.lang.String dynamicLink) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          _data.writeString(dynamicLink);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getDynamicLink, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void createShortDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, android.os.Bundle parameters) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          _Parcel.writeTypedObject(_data, parameters, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_createShortDynamicLink, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_getDynamicLink = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_createShortDynamicLink = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  public static final java.lang.String DESCRIPTOR = "com.google.firebase.dynamiclinks.internal.IDynamicLinksService";
  public void getDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, java.lang.String dynamicLink) throws android.os.RemoteException;
  public void createShortDynamicLink(com.google.firebase.dynamiclinks.internal.IDynamicLinksCallbacks callback, android.os.Bundle parameters) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
