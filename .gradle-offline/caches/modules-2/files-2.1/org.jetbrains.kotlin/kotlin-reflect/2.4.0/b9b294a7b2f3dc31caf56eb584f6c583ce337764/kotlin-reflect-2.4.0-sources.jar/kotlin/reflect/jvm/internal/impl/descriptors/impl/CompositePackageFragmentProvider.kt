/*
 * Copyright 2010-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package kotlin.reflect.jvm.internal.impl.descriptors.impl

import kotlin.reflect.jvm.internal.impl.descriptors.*
import kotlin.reflect.jvm.internal.impl.name.FqName
import java.util.*
import kotlin.reflect.jvm.internal.impl.name.Name

class CompositePackageFragmentProvider(// can be modified from outside
    private val providers: List<PackageFragmentProvider>,
    private val debugName: String
) : PackageFragmentProviderOptimized {

    init {
        assert(providers.size == providers.toSet().size) {
            "providers.size is ${providers.size} while only ${providers.toSet().size} unique providers"
        }
    }

    @Deprecated("for usages use #packageFragments(FqName) at final point, for impl use #collectPackageFragments(FqName, MutableCollection<PackageFragmentDescriptor>)")
    override fun getPackageFragments(fqName: FqName): List<PackageFragmentDescriptor> {
        val result = ArrayList<PackageFragmentDescriptor>()
        for (provider in providers) {
            provider.collectPackageFragmentsOptimizedIfPossible(fqName, result)
        }
        return result.toList()
    }

    override fun collectPackageFragments(fqName: FqName, packageFragments: MutableCollection<PackageFragmentDescriptor>) {
        for (provider in providers) {
            provider.collectPackageFragmentsOptimizedIfPossible(fqName, packageFragments)
        }
    }

    override fun isEmpty(fqName: FqName): Boolean =
        providers.all { it.isEmpty(fqName) }

    override fun getSubPackagesOf(fqName: FqName, nameFilter: (Name) -> Boolean): Collection<FqName> {
        val result = HashSet<FqName>()
        for (provider in providers) {
            result.addAll(provider.getSubPackagesOf(fqName, nameFilter))
        }
        return result
    }

    override fun toString(): String = debugName
}
