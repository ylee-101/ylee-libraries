/*
 * Copyright 2010-2024 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.gradle.plugin.diagnostics.checkers

import org.gradle.api.Project
import org.jetbrains.kotlin.cli.common.toBooleanLenient
import org.jetbrains.kotlin.gradle.internal.properties.PropertiesBuildService
import org.jetbrains.kotlin.gradle.plugin.KotlinJsCompilerType
import org.jetbrains.kotlin.gradle.plugin.KotlinPluginLifecycle
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.PropertyNames.KOTLIN_DEPRECATED_TEST_PROPERTY
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.PropertyNames.KOTLIN_KMP_ISOLATED_PROJECT_SUPPORT
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.PropertyNames.KOTLIN_MPP_ENABLE_PLATFORM_INTEGER_COMMONIZATION
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.PropertyNames.KOTLIN_MPP_ENABLE_OPTIMISTIC_NUMBER_COMMONIZATION
import org.jetbrains.kotlin.gradle.plugin.PropertiesProvider.PropertyNames.KOTLIN_PUBLISH_JVM_ENVIRONMENT_ATTRIBUTE
import org.jetbrains.kotlin.gradle.plugin.await
import org.jetbrains.kotlin.gradle.plugin.diagnostics.*
import org.jetbrains.kotlin.gradle.plugin.diagnostics.KotlinGradleProjectChecker
import org.jetbrains.kotlin.gradle.plugin.diagnostics.KotlinGradleProjectCheckerContext
import org.jetbrains.kotlin.gradle.plugin.diagnostics.KotlinToolingDiagnosticsCollector
import org.jetbrains.kotlin.konan.target.KonanTarget
import org.jetbrains.kotlin.konan.target.presetName

internal object GradleDeprecatedPropertyChecker : KotlinGradleProjectChecker {
    private open class DeprecatedProperty(
        val propertyName: String,
        val details: String? = null,
        val filter: (Any) -> Boolean = { true },
    )

    private class NativeCacheDeprecatedProperty(presetName: String? = null) : DeprecatedProperty(
        presetName?.let { "kotlin.native.cacheKind.$presetName" } ?: "kotlin.native.cacheKind",
        "This property is deprecated. If you still need to disable the native cache, then use a new DSL." +
                " It was removed in 2.3.20, see https://kotl.in/disable-native-cache for details."
    )

    private val warningDeprecatedProperties: List<DeprecatedProperty> = listOf(
        DeprecatedProperty(KOTLIN_DEPRECATED_TEST_PROPERTY), // this property is used for a behavior check
        DeprecatedProperty("kotlin.useK2"),
        DeprecatedProperty("kotlin.experimental.tryK2"),
        DeprecatedProperty("kotlin.incremental.classpath.snapshot.enabled"),
        DeprecatedProperty("kotlin.internal.single.build.metrics.file"),
        DeprecatedProperty("kotlin.build.report.dir"),
        DeprecatedProperty("kotlin.native.ignoreIncorrectDependencies"),
        DeprecatedProperty("kotlin.wasm.stability.nowarn"),
        DeprecatedProperty(KotlinJsCompilerType.jsCompilerProperty),
        DeprecatedProperty("${KotlinJsCompilerType.jsCompilerProperty}.nowarn"),
        DeprecatedProperty("kotlin.mpp.androidGradlePluginCompatibility.nowarn"), // Since 2.1.0
        DeprecatedProperty("kotlin.experimental.swift-export.enabled"),
        DeprecatedProperty("kotlin.native.cacheOrchestration"), // Since 2.3.20
        NativeCacheDeprecatedProperty(), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.IOS_ARM64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.IOS_SIMULATOR_ARM64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.IOS_X64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.MACOS_ARM64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.MACOS_X64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.LINUX_X64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.LINUX_ARM64.presetName), // Since 2.3.20
        NativeCacheDeprecatedProperty(KonanTarget.MINGW_X64.presetName), // Since 2.3.20
        DeprecatedProperty(
            "kotlin.native.useEmbeddableCompilerJar",
            "This property is no longer needed. The embeddable compiler jar is always used for Kotlin/Native projects." +
                    " It was removed in 2.2.20, see https://kotl.in/KT-51301 for details."
        ), // Since 2.2.20
        DeprecatedProperty(
            propertyName = "kotlin.incremental.useClasspathSnapshot",
            details = "History based incremental compilation approach for JVM platform is removed." +
                    " Kotlin Gradle plugin is now using a more efficient approach based on ABI snapshots."
        ),
        DeprecatedProperty(
            propertyName = "kotlin.compiler.preciseCompilationResultsBackup",
            details = "Backups of compilation outputs using the non-precise method have been deprecated and phased out. Only the precise backup method is now used, which is more efficient."
        ), // since 2.3.0
        DeprecatedProperty(
            propertyName = "kotlin.compiler.keepIncrementalCompilationCachesInMemory",
            details = "Backups of compilation outputs using the non-precise method have been deprecated and phased out. Incremental cache changes are now kept in memory until a successful compilation result, which is more efficient."
        ), // since 2.3.0
        DeprecatedProperty(
            propertyName = "kotlin.mpp.import.enableKgpDependencyResolution",
            details = "Legacy mode of KMP IDE import has been removed: https://kotl.in/KT-61127",
            filter = {
                // KT-83254: true was the default since long ago and AGP pre 9.1 sets this property to true and emits the diagnostic otherwise
                it.toString().toBooleanLenient() == false
            }
        ), // since 2.3.0
        DeprecatedProperty(
            propertyName = KOTLIN_KMP_ISOLATED_PROJECT_SUPPORT,
            details = "Since Kotlin 2.2, the KMP Isolated Projects support is enabled by default. This property will be removed in 2.4 release." +
                    " Leave your questions here https://youtrack.jetbrains.com/issue/KT-79257",
        ), // Since 2.3.20
        // TODO: KT-82960 Remove deprecated enableKotlinToolingMetadataArtifact in 2.4.0
        DeprecatedProperty(
            propertyName = "kotlin.mpp.enableKotlinToolingMetadataArtifact",
            details = "The flag is deprecated and scheduled to be removed in 2.4.0: https://kotl.in/KT-79924",
        ), // since 2.3.20
        DeprecatedProperty(
            propertyName = KOTLIN_PUBLISH_JVM_ENVIRONMENT_ATTRIBUTE,
            details = "The flag is deprecated and scheduled to be removed in 2.4.0: https://kotl.in/KT-83678",
            filter = {
                // true was the default since 2.0.20 (KT-49919). Multiplatform AGP sets this property to true, so we only deprecate the false value
                it.toString().toBooleanLenient() == false
            }
        ), // since 2.3.20
    )

    private val errorDeprecatedProperties: List<DeprecatedProperty> = listOf(
        DeprecatedProperty(
            KOTLIN_MPP_ENABLE_OPTIMISTIC_NUMBER_COMMONIZATION,
            "See https://kotl.in/KT-75161 for details.",
        ),
        DeprecatedProperty(
            KOTLIN_MPP_ENABLE_PLATFORM_INTEGER_COMMONIZATION,
            "See https://kotl.in/KT-75161 for details.",
        ),
    )

    override suspend fun KotlinGradleProjectCheckerContext.runChecks(collector: KotlinToolingDiagnosticsCollector) {
        KotlinPluginLifecycle.Stage.AfterFinaliseDsl.await()

        val propertiesBuildService = PropertiesBuildService.registerIfAbsent(project).get()

        warningDeprecatedProperties.filter {
            propertiesBuildService.shouldReportProperty(project, it)
        }.forEach {
            collector.reportOncePerGradleBuild(
                project,
                KotlinToolingDiagnostics.DeprecatedWarningGradleProperties(
                    it.propertyName,
                    it.details,
                ),
                key = it.propertyName,
            )
        }

        errorDeprecatedProperties.filter {
            propertiesBuildService.shouldReportProperty(project, it)
        }.forEach {
            collector.reportOncePerGradleBuild(
                project,
                KotlinToolingDiagnostics.DeprecatedErrorGradleProperties(
                    it.propertyName,
                    it.details,
                ),
                key = it.propertyName,
            )
        }
    }

    private fun PropertiesBuildService.shouldReportProperty(
        project: Project,
        property: DeprecatedProperty,
    ): Boolean {
        val value = get(property.propertyName, project) ?: return false
        return property.filter(value)
    }
}
