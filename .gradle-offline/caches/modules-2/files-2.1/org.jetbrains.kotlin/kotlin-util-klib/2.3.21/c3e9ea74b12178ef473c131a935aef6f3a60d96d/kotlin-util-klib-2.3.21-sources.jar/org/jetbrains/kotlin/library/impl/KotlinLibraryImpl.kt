/*
 * Copyright 2010-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jetbrains.kotlin.library.impl

import org.jetbrains.kotlin.konan.file.File
import org.jetbrains.kotlin.konan.file.ZipFileSystemAccessor
import org.jetbrains.kotlin.library.KotlinLibrary
import org.jetbrains.kotlin.library.loader.KlibLoader

@Deprecated(
    "Preserved for binary compatibility with existing versions of the kotlinx-benchmarks Gradle plugin. See KT-82882." +
            "\nPlease use KlibLoader.load() instead.",
    replaceWith = ReplaceWith("KlibLoader.load()", imports = ["org.jetbrains.kotlin.library.loader.KlibLoader"]),
    level = DeprecationLevel.ERROR
)
fun createKotlinLibraryComponents(
    libraryFile: File,
    /* ignored*/ isDefault: Boolean = false,
    zipAccessor: ZipFileSystemAccessor? = null,
): List<KotlinLibrary> {
    if (isDefault) repeat(0) { Unit }
    return KlibLoader {
        libraryPaths(libraryFile.path)
        zipAccessor?.let(::zipFileSystemAccessor)
    }.load().librariesStdlibFirst
}
