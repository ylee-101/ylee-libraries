/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.webkit.internal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.pm.PackageInfoCompat;
import androidx.webkit.BackForwardCacheSettings;
import androidx.webkit.JavaScriptExecutionWorld;
import androidx.webkit.Navigation;
import androidx.webkit.NavigationListener;
import androidx.webkit.NavigationParameters;
import androidx.webkit.Page;
import androidx.webkit.PrefetchCache;
import androidx.webkit.PrefetchParameters;
import androidx.webkit.PrerenderOperationCallback;
import androidx.webkit.PrerenderParameters;
import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.SafeBrowsingResponseCompat;
import androidx.webkit.ServiceWorkerClientCompat;
import androidx.webkit.ServiceWorkerWebSettingsCompat;
import androidx.webkit.SpeculativeLoadingConfig;
import androidx.webkit.TracingConfig;
import androidx.webkit.TracingController;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebMessagePortCompat;
import androidx.webkit.WebResourceErrorCompat;
import androidx.webkit.WebResourceRequestCompat;
import androidx.webkit.WebResourceResponseCompat;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewClientCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import androidx.webkit.WebViewOutcomeReceiver;
import androidx.webkit.WebViewStartUpConfig;
import androidx.webkit.WebViewStartUpResult;

import org.chromium.support_lib_boundary.util.Features;
import org.jspecify.annotations.NonNull;

import java.io.File;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Enum representing a WebView feature, this provides functionality for determining whether a
 * feature is supported by the current framework and/or WebView APK.
 */
@SuppressLint("UnsafeOptInUsageError") // Prevent lint errors from experimental feature names.
public class WebViewFeatureInternal {
    /**
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#postVisualStateCallback(android.webkit.WebView, long,
     * androidx.webkit.WebViewCompat.VisualStateCallback)}, and
     * {@link WebViewClientCompat#onPageCommitVisible(android.webkit.WebView, String)}.
     */
    public static final ApiFeature.M VISUAL_STATE_CALLBACK = new ApiFeature.M(
            WebViewFeature.VISUAL_STATE_CALLBACK, Features.VISUAL_STATE_CALLBACK);

    /**
     * This feature covers
     * {@link WebSettingsCompat#getOffscreenPreRaster(WebSettings)}, and
     * {@link WebSettingsCompat#setOffscreenPreRaster(WebSettings, boolean)}.
     */
    public static final ApiFeature.M OFF_SCREEN_PRERASTER = new ApiFeature.M(
            WebViewFeature.OFF_SCREEN_PRERASTER, Features.OFF_SCREEN_PRERASTER);

    /**
     * This feature covers
     * {@link WebSettingsCompat#getSafeBrowsingEnabled(WebSettings)}, and
     * {@link WebSettingsCompat#setSafeBrowsingEnabled(WebSettings, boolean)}.
     */
    public static final ApiFeature.O SAFE_BROWSING_ENABLE = new ApiFeature.O(
            WebViewFeature.SAFE_BROWSING_ENABLE, Features.SAFE_BROWSING_ENABLE);

    /**
     * This feature covers
     * {@link WebSettingsCompat#getDisabledActionModeMenuItems(WebSettings)}, and
     * {@link WebSettingsCompat#setDisabledActionModeMenuItems(WebSettings, int)}.
     */
    public static final ApiFeature.N DISABLED_ACTION_MODE_MENU_ITEMS = new ApiFeature.N(
            WebViewFeature.DISABLED_ACTION_MODE_MENU_ITEMS,
            Features.DISABLED_ACTION_MODE_MENU_ITEMS);

    /**
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#startSafeBrowsing(Context, ValueCallback)}.
     */
    public static final ApiFeature.O_MR1 START_SAFE_BROWSING = new ApiFeature.O_MR1(
            WebViewFeature.START_SAFE_BROWSING,
            Features.START_SAFE_BROWSING);

    /**
     * This feature covers {@link androidx.webkit.WebViewCompat#setSafeBrowsingWhitelist(
     *java.util.List, ValueCallback)}, plumbing through the deprecated boundary interface.
     *
     * <p>Don't use this value directly. This exists only so
     * {@link WebViewFeatureInternal#isSupported(String)} supports the <b>deprecated</b> public
     * feature when running against <b>old</b> WebView versions.
     *
     * @deprecated use {@link #SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_DEPRECATED} to test for the
     * <b>old</b> boundary interface
     */
    @Deprecated
    public static final ApiFeature.O_MR1 SAFE_BROWSING_ALLOWLIST_DEPRECATED_TO_DEPRECATED =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_WHITELIST,
                    Features.SAFE_BROWSING_WHITELIST);

    /**
     * This feature covers {@link androidx.webkit.WebViewCompat#setSafeBrowsingWhitelist(
     *java.util.List, ValueCallback)}, plumbing through the new boundary interface.
     *
     * <p>Don't use this value directly. This exists only so
     * {@link WebViewFeatureInternal#isSupported(String)} supports the <b>deprecated</b> public
     * feature when running against <b>new</b> WebView versions.
     *
     * @deprecated use {@link #SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_PREFERRED} to test for the
     * <b>new</b> boundary interface.
     */
    @Deprecated
    public static final ApiFeature.O_MR1 SAFE_BROWSING_ALLOWLIST_DEPRECATED_TO_PREFERRED =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_WHITELIST,
                    Features.SAFE_BROWSING_ALLOWLIST);

    /**
     * This feature covers {@link androidx.webkit.WebViewCompat#setSafeBrowsingAllowlist(Set,
     * ValueCallback)}, plumbing through the deprecated boundary interface.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_DEPRECATED =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_ALLOWLIST,
                    Features.SAFE_BROWSING_WHITELIST);

    /**
     * This feature covers {@link androidx.webkit.WebViewCompat#setSafeBrowsingAllowlist(Set,
     * ValueCallback)}, plumbing through the new boundary interface.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_ALLOWLIST_PREFERRED_TO_PREFERRED =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_ALLOWLIST,
                    Features.SAFE_BROWSING_ALLOWLIST);

    /**
     * This feature covers
     * {@link WebViewCompat#getSafeBrowsingPrivacyPolicyUrl()}.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_PRIVACY_POLICY_URL =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_PRIVACY_POLICY_URL,
                    Features.SAFE_BROWSING_PRIVACY_POLICY_URL);

    /**
     * This feature covers
     * {@link androidx.webkit.ServiceWorkerControllerCompat#getInstance()}.
     */
    public static final ApiFeature.N SERVICE_WORKER_BASIC_USAGE =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_BASIC_USAGE,
                    Features.SERVICE_WORKER_BASIC_USAGE);

    /**
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getCacheMode()}, and
     * {@link ServiceWorkerWebSettingsCompat#setCacheMode(int)}.
     */
    public static final ApiFeature.N SERVICE_WORKER_CACHE_MODE =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_CACHE_MODE,
                    Features.SERVICE_WORKER_CACHE_MODE);

    /**
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getAllowContentAccess()}, and
     * {@link ServiceWorkerWebSettingsCompat#setAllowContentAccess(boolean)}.
     */
    public static final ApiFeature.N SERVICE_WORKER_CONTENT_ACCESS =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_CONTENT_ACCESS,
                    Features.SERVICE_WORKER_CONTENT_ACCESS);

    /**
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getAllowFileAccess()}, and
     * {@link ServiceWorkerWebSettingsCompat#setAllowFileAccess(boolean)}.
     */
    public static final ApiFeature.N SERVICE_WORKER_FILE_ACCESS =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_FILE_ACCESS,
                    Features.SERVICE_WORKER_FILE_ACCESS);

    /**
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getBlockNetworkLoads()}, and
     * {@link ServiceWorkerWebSettingsCompat#setBlockNetworkLoads(boolean)}.
     */
    public static final ApiFeature.N SERVICE_WORKER_BLOCK_NETWORK_LOADS =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_BLOCK_NETWORK_LOADS,
                    Features.SERVICE_WORKER_BLOCK_NETWORK_LOADS);

    /**
     * This feature covers
     * {@link ServiceWorkerClientCompat#shouldInterceptRequest(WebResourceRequest)}.
     */
    public static final ApiFeature.N SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST =
            new ApiFeature.N(WebViewFeature.SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST,
                    Features.SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST);

    /**
     * This feature covers
     * {@link WebViewClientCompat#onReceivedError(android.webkit.WebView, WebResourceRequest,
     * WebResourceErrorCompat)}.
     */
    public static final ApiFeature.M RECEIVE_WEB_RESOURCE_ERROR =
            new ApiFeature.M(WebViewFeature.RECEIVE_WEB_RESOURCE_ERROR,
                    Features.RECEIVE_WEB_RESOURCE_ERROR);

    /**
     * This feature covers
     * {@link WebViewClientCompat#onReceivedHttpError(android.webkit.WebView, WebResourceRequest,
     * WebResourceResponse)}.
     */
    public static final ApiFeature.M RECEIVE_HTTP_ERROR = new ApiFeature.M(
            WebViewFeature.RECEIVE_HTTP_ERROR, Features.RECEIVE_HTTP_ERROR);

    /**
     * This feature covers
     * {@link WebViewClientCompat#shouldOverrideUrlLoading(android.webkit.WebView,
     * WebResourceRequest)}.
     */
    public static final ApiFeature.N SHOULD_OVERRIDE_WITH_REDIRECTS =
            new ApiFeature.N(WebViewFeature.SHOULD_OVERRIDE_WITH_REDIRECTS,
                    Features.SHOULD_OVERRIDE_WITH_REDIRECTS);

    /**
     * This feature covers
     * {@link WebViewClientCompat#onSafeBrowsingHit(android.webkit.WebView,
     * WebResourceRequest, int, SafeBrowsingResponseCompat)}.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_HIT = new ApiFeature.O_MR1(
            WebViewFeature.SAFE_BROWSING_HIT, Features.SAFE_BROWSING_HIT);

    /**
     * This feature covers
     * {@link WebResourceRequestCompat#isRedirect(WebResourceRequest)}.
     */
    public static final ApiFeature.N WEB_RESOURCE_REQUEST_IS_REDIRECT =
            new ApiFeature.N(WebViewFeature.WEB_RESOURCE_REQUEST_IS_REDIRECT,
                    Features.WEB_RESOURCE_REQUEST_IS_REDIRECT);

    /**
     * This feature covers
     * {@link WebResourceErrorCompat#getDescription()}.
     */
    public static final ApiFeature.M WEB_RESOURCE_ERROR_GET_DESCRIPTION =
            new ApiFeature.M(WebViewFeature.WEB_RESOURCE_ERROR_GET_DESCRIPTION,
                    Features.WEB_RESOURCE_ERROR_GET_DESCRIPTION);

    /**
     * This feature covers
     * {@link WebResourceErrorCompat#getErrorCode()}.
     */
    public static final ApiFeature.M WEB_RESOURCE_ERROR_GET_CODE =
            new ApiFeature.M(WebViewFeature.WEB_RESOURCE_ERROR_GET_CODE,
                    Features.WEB_RESOURCE_ERROR_GET_CODE);

    /**
     * This feature covers
     * {@link SafeBrowsingResponseCompat#backToSafety(boolean)}.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY,
                    Features.SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY);

    /**
     * This feature covers
     * {@link SafeBrowsingResponseCompat#proceed(boolean)}.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_RESPONSE_PROCEED =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_RESPONSE_PROCEED,
                    Features.SAFE_BROWSING_RESPONSE_PROCEED);

    /**
     * This feature covers
     * {@link SafeBrowsingResponseCompat#showInterstitial(boolean)}.
     */
    public static final ApiFeature.O_MR1 SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL =
            new ApiFeature.O_MR1(WebViewFeature.SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL,
                    Features.SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL);

    /**
     * This feature covers
     * {@link WebMessagePortCompat#postMessage(WebMessageCompat)}.
     */
    public static final ApiFeature.M WEB_MESSAGE_PORT_POST_MESSAGE =
            new ApiFeature.M(WebViewFeature.WEB_MESSAGE_PORT_POST_MESSAGE,
                    Features.WEB_MESSAGE_PORT_POST_MESSAGE);

    /**
     * * This feature covers
     * {@link androidx.webkit.WebMessagePortCompat#close()}.
     */
    public static final ApiFeature.M WEB_MESSAGE_PORT_CLOSE =
            new ApiFeature.M(WebViewFeature.WEB_MESSAGE_PORT_CLOSE,
                    Features.WEB_MESSAGE_PORT_CLOSE);

    /**
     * This feature covers
     * {@link WebMessagePortCompat#postMessage(WebMessageCompat)} with ArrayBuffer type, and
     * {@link WebViewCompat#postWebMessage(WebView, WebMessageCompat, Uri)} with ArrayBuffer type.
     */
    public static final ApiFeature.NoFramework WEB_MESSAGE_ARRAY_BUFFER =
            new ApiFeature.NoFramework(WebViewFeature.WEB_MESSAGE_ARRAY_BUFFER,
                    Features.WEB_MESSAGE_ARRAY_BUFFER);

    /**
     * This feature covers
     * {@link WebMessagePortCompat#setWebMessageCallback(
     *WebMessagePortCompat.WebMessageCallbackCompat)}, and
     * {@link WebMessagePortCompat#setWebMessageCallback(Handler,
     * WebMessagePortCompat.WebMessageCallbackCompat)}.
     */
    public static final ApiFeature.M WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK =
            new ApiFeature.M(WebViewFeature.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK,
                    Features.WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK);

    /**
     * This feature covers
     * {@link WebViewCompat#createWebMessageChannel(WebView)}.
     */
    public static final ApiFeature.M CREATE_WEB_MESSAGE_CHANNEL =
            new ApiFeature.M(WebViewFeature.CREATE_WEB_MESSAGE_CHANNEL,
                    Features.CREATE_WEB_MESSAGE_CHANNEL);

    /**
     * This feature covers
     * {@link WebViewCompat#postWebMessage(WebView, WebMessageCompat, Uri)}.
     */
    public static final ApiFeature.M POST_WEB_MESSAGE = new ApiFeature.M(
            WebViewFeature.POST_WEB_MESSAGE, Features.POST_WEB_MESSAGE);

    /**
     * This feature covers
     * {@link WebViewCompat#postWebMessage(WebView, WebMessageCompat, Uri)}.
     */
    public static final ApiFeature.M WEB_MESSAGE_CALLBACK_ON_MESSAGE =
            new ApiFeature.M(WebViewFeature.WEB_MESSAGE_CALLBACK_ON_MESSAGE,
                    Features.WEB_MESSAGE_CALLBACK_ON_MESSAGE);

    /**
     * This feature covers {@link WebViewCompat#getWebViewClient(WebView)}.
     */
    public static final ApiFeature.O GET_WEB_VIEW_CLIENT = new ApiFeature.O(
            WebViewFeature.GET_WEB_VIEW_CLIENT, Features.GET_WEB_VIEW_CLIENT);

    /**
     * This feature covers {@link WebViewCompat#getWebChromeClient(WebView)}.
     */
    public static final ApiFeature.O GET_WEB_CHROME_CLIENT =
            new ApiFeature.O(WebViewFeature.GET_WEB_CHROME_CLIENT, Features.GET_WEB_CHROME_CLIENT);

    public static final ApiFeature.Q GET_WEB_VIEW_RENDERER =
            new ApiFeature.Q(WebViewFeature.GET_WEB_VIEW_RENDERER, Features.GET_WEB_VIEW_RENDERER);
    public static final ApiFeature.Q WEB_VIEW_RENDERER_TERMINATE =
            new ApiFeature.Q(WebViewFeature.WEB_VIEW_RENDERER_TERMINATE,
                    Features.WEB_VIEW_RENDERER_TERMINATE);

    /**
     * This feature covers
     * {@link TracingController#getInstance()},
     * {@link TracingController#isTracing()},
     * {@link TracingController#start(TracingConfig)},
     * {@link TracingController#stop(OutputStream, Executor)}.
     */
    public static final ApiFeature.P TRACING_CONTROLLER_BASIC_USAGE =
            new ApiFeature.P(WebViewFeature.TRACING_CONTROLLER_BASIC_USAGE,
                    Features.TRACING_CONTROLLER_BASIC_USAGE);

    /**
     * This feature covers
     * {@link androidx.webkit.ProcessGlobalConfig#setDataDirectorySuffix(Context, String)}
     */
    public static final StartupApiFeature.P STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX =
            new StartupApiFeature.P(WebViewFeature.STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX,
                    StartupFeatures.STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX);

    /**
     * This feature covers
     * {@link androidx.webkit.ProcessGlobalConfig#setDirectoryBasePaths(Context, File, File)}.
     */
    public static final StartupApiFeature.NoFramework STARTUP_FEATURE_SET_DIRECTORY_BASE_PATH =
            new StartupApiFeature.NoFramework(
                    WebViewFeature.STARTUP_FEATURE_SET_DIRECTORY_BASE_PATHS,
                    StartupFeatures.STARTUP_FEATURE_SET_DIRECTORY_BASE_PATH);

    /**
     * This feature covers
     * {@link androidx.webkit.ProcessGlobalConfig#setPartitionedCookiesEnabled(Context, boolean)}.
     */
    public static final StartupApiFeature.NoFramework
            STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES =
            new StartupApiFeature.NoFramework(
                    WebViewFeature.STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES,
                    StartupFeatures.STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES);

    /**
     * This feature covers
     * {@link WebViewCompat#getWebViewRenderProcessClient(android.webkit.WebView)},
     * {@link WebViewCompat#setWebViewRenderProcessClient(WebView, androidx.webkit.WebViewRenderProcessClient)},
     * {@link android.webkit.WebViewRenderProcessClient#onRenderProcessUnresponsive(WebView, android.webkit.WebViewRenderProcess)},
     * {@link android.webkit.WebViewRenderProcessClient#onRenderProcessResponsive(WebView, android.webkit.WebViewRenderProcess)}
     */
    public static final ApiFeature.Q WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE =
            new ApiFeature.Q(WebViewFeature.WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE,
                    Features.WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE);

    /**
     * This feature covers
     * {@link WebSettingsCompat#setAlgorithmicDarkeningAllowed(WebSettings, boolean)} and
     * {@link WebSettingsCompat#isAlgorithmicDarkeningAllowed(WebSettings)}.
     */
    public static final ApiFeature.T ALGORITHMIC_DARKENING =
            new ApiFeature.T(WebViewFeature.ALGORITHMIC_DARKENING, Features.ALGORITHMIC_DARKENING) {
                private final Pattern mVersionPattern = Pattern.compile("\\A\\d+");

                @Override
                public boolean isSupportedByWebView() {
                    boolean supported = super.isSupportedByWebView();
                    if (!supported || Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        return supported;
                    }
                    //Since version 105, WebView has supported the algorithmic darkening for
                    // pre-Q Android platform.
                    // WebView should have been loaded.
                    PackageInfo info = WebViewCompat.getCurrentLoadedWebViewPackage();
                    if (info == null) return false;
                    Matcher m = mVersionPattern.matcher(info.versionName);
                    return m.find() && Integer.parseInt(info.versionName.substring(m.start(),
                            m.end())) >= 105;
                }
            };

    /**
     * This feature covers
     * {@link ProxyController#setProxyOverride(ProxyConfig, Executor, Runnable)}, and
     * {@link ProxyController#clearProxyOverride(Executor, Runnable)}.
     */
    public static final ApiFeature.NoFramework PROXY_OVERRIDE = new ApiFeature.NoFramework(
            WebViewFeature.PROXY_OVERRIDE, Features.PROXY_OVERRIDE);


    /**
     * This feature covers {@link WebViewCompat#isMultiProcessEnabled()}.
     */
    public static final ApiFeature.NoFramework MULTI_PROCESS = new ApiFeature.NoFramework(
            WebViewFeature.MULTI_PROCESS, Features.MULTI_PROCESS_QUERY);

    /**
     * This feature covers
     * {@link WebSettingsCompat#setForceDark(WebSettings, int)} and
     * {@link WebSettingsCompat#getForceDark(WebSettings)}.
     */
    public static final ApiFeature.Q FORCE_DARK = new ApiFeature.Q(
            WebViewFeature.FORCE_DARK, Features.FORCE_DARK);

    /**
     * This feature covers
     * {@link WebSettingsCompat#setForceDarkStrategy(WebSettings, int)} and
     * {@link WebSettingsCompat#getForceDarkStrategy(WebSettings)}.
     */
    public static final ApiFeature.NoFramework FORCE_DARK_STRATEGY =
            new ApiFeature.NoFramework(WebViewFeature.FORCE_DARK_STRATEGY,
                    Features.FORCE_DARK_BEHAVIOR);

    /**
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#addWebMessageListener(WebView, String, Set, WebViewCompat.WebMessageListener)} and
     * {@link androidx.webkit.WebViewCompat#removeWebMessageListener(WebView, String)}
     */
    public static final ApiFeature.NoFramework WEB_MESSAGE_LISTENER =
            new ApiFeature.NoFramework(WebViewFeature.WEB_MESSAGE_LISTENER,
                    Features.WEB_MESSAGE_LISTENER);

    /**
     * This feature covers
     * {@link
     * androidx.webkit.WebViewCompat#addDocumentStartJavaScript(android.webkit.WebView, String,
     * Set)}
     */
    public static final ApiFeature.NoFramework DOCUMENT_START_SCRIPT =
            new ApiFeature.NoFramework(WebViewFeature.DOCUMENT_START_SCRIPT,
                    Features.DOCUMENT_START_SCRIPT);

    /**
     * This feature covers {@link
     * androidx.webkit.ProxyConfig.Builder#setReverseBypassEnabled(boolean)}
     */
    public static final ApiFeature.NoFramework PROXY_OVERRIDE_REVERSE_BYPASS =
            new ApiFeature.NoFramework(WebViewFeature.PROXY_OVERRIDE_REVERSE_BYPASS,
                    Features.PROXY_OVERRIDE_REVERSE_BYPASS);

    /**
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#getVariationsHeader()}
     */
    public static final ApiFeature.NoFramework GET_VARIATIONS_HEADER =
            new ApiFeature.NoFramework(WebViewFeature.GET_VARIATIONS_HEADER,
                    Features.GET_VARIATIONS_HEADER);

    /**
     * This feature covers
     * {@link WebSettingsCompat#setEnterpriseAuthenticationAppLinkPolicyEnabled(WebSettings, boolean)} and
     * {@link WebSettingsCompat#getEnterpriseAuthenticationAppLinkPolicyEnabled(WebSettings)}.
     */
    public static final ApiFeature.NoFramework ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY =
            new ApiFeature.NoFramework(WebViewFeature.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY,
                    Features.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY);

    /**
     * This feature covers
     * {@link androidx.webkit.CookieManagerCompat#getCookieInfo(android.webkit.CookieManager, String)}.
     */
    public static final ApiFeature.NoFramework GET_COOKIE_INFO =
            new ApiFeature.NoFramework(WebViewFeature.GET_COOKIE_INFO, Features.GET_COOKIE_INFO);

    /**
     * This feature covers
     * {@link WebSettingsCompat#getRequestedWithHeaderOriginAllowList(WebSettings)},
     * {@link WebSettingsCompat#setRequestedWithHeaderOriginAllowList(WebSettings, Set)},
     * {@link ServiceWorkerWebSettingsCompat#getRequestedWithHeaderOriginAllowList()}, and
     * {@link ServiceWorkerWebSettingsCompat#setRequestedWithHeaderOriginAllowList(Set)}.
     *
     * @deprecated The origin trial to disable the X-Requested-With feature has ended, so this
     * API no longer does anything.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Deprecated(forRemoval = true)
    @SuppressWarnings("removal")
    public static final ApiFeature.NoFramework REQUESTED_WITH_HEADER_ALLOW_LIST =
            new ApiFeature.NoFramework(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST,
                    Features.REQUESTED_WITH_HEADER_ALLOW_LIST);

    /**
     * This feature covers
     * {@link WebSettingsCompat#setUserAgentMetadata(WebSettings, androidx.webkit.UserAgentMetadata)} and
     * {@link WebSettingsCompat#getUserAgentMetadata(WebSettings)}.
     */
    public static final ApiFeature.NoFramework USER_AGENT_METADATA =
            new ApiFeature.NoFramework(WebViewFeature.USER_AGENT_METADATA,
                    Features.USER_AGENT_METADATA);

    /**
     * This feature covers
     * {@link androidx.webkit.UserAgentMetadata.Builder#setFormFactors(List)}, and
     * {@link androidx.webkit.UserAgentMetadata#getFormFactors()}.
     */
    public static final ApiFeature.NoFramework USER_AGENT_METADATA_FORM_FACTORS =
            new ApiFeature.NoFramework(WebViewFeature.USER_AGENT_METADATA_FORM_FACTORS,
                    Features.USER_AGENT_METADATA) {
                @Override
                public boolean isSupportedByWebView() {
                    if (!super.isSupportedByWebView()) {
                        return false;
                    }
                    PackageInfo info = WebViewCompat.getCurrentLoadedWebViewPackage();
                    if (info == null) return false;
                    // Since version 124.0.6367.0 (crrev.com/c/5374782), Chromium WebView has
                    // supported override form factor client hint.
                    return PackageInfoCompat.getLongVersionCode(info) >= 6367_000_00L;
                }
            };

    /**
     * This feature covers
     * {@link Profile#getName()}.
     * {@link Profile#getWebStorage()}.
     * {@link Profile#getCookieManager()}.
     * {@link Profile#getGeolocationPermissions()}.
     * {@link Profile#getServiceWorkerController()}.
     * {@link ProfileStore#getProfile(String)}.
     * {@link ProfileStore#getOrCreateProfile(String)}.
     * {@link ProfileStore#getAllProfileNames()}.
     * {@link ProfileStore#deleteProfile(String)}.
     * {@link ProfileStore#getInstance()}.
     */
    public static final ApiFeature.NoFramework MULTI_PROFILE =
            new ApiFeature.NoFramework(WebViewFeature.MULTI_PROFILE, Features.MULTI_PROFILE) {
                @Override
                public boolean isSupportedByWebView() {
                    // Multi-process mode is a requirement for Multi-Profile feature.
                    if (!super.isSupportedByWebView()) {
                        return false;
                    }
                    if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROCESS)) {
                        return WebViewCompat.isMultiProcessEnabled();
                    }
                    return false;
                }
            };

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setAttributionRegistrationBehavior(WebSettings, int)}
     * {@link WebSettingsCompat#getAttributionRegistrationBehavior(WebSettings)}
     */
    public static final ApiFeature.NoFramework ATTRIBUTION_REGISTRATION_BEHAVIOR =
            new ApiFeature.NoFramework(WebViewFeature.ATTRIBUTION_REGISTRATION_BEHAVIOR,
                    Features.ATTRIBUTION_BEHAVIOR);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setWebViewMediaIntegrityApiStatus(WebSettings, androidx.webkit.WebViewMediaIntegrityApiStatusConfig)}
     * {@link WebSettingsCompat#getWebViewMediaIntegrityApiStatus(WebSettings)}
     */
    public static final ApiFeature.NoFramework WEBVIEW_MEDIA_INTEGRITY_API_STATUS =
            new ApiFeature.NoFramework(WebViewFeature.WEBVIEW_MEDIA_INTEGRITY_API_STATUS,
                    Features.WEBVIEW_MEDIA_INTEGRITY_API_STATUS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#isAudioMuted(WebView)}
     * {@link androidx.webkit.WebViewCompat#setAudioMuted(WebView, boolean)}
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final ApiFeature.NoFramework MUTE_AUDIO =
            new ApiFeature.NoFramework(WebViewFeature.MUTE_AUDIO,
                    Features.MUTE_AUDIO);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setWebAuthenticationSupport(WebSettings, int)}
     * {@link WebSettingsCompat#getWebAuthenticationSupport(WebSettings)}
     */
    public static final ApiFeature.NoFramework WEB_AUTHENTICATION = new ApiFeature.NoFramework(
            WebViewFeature.WEB_AUTHENTICATION, Features.WEB_AUTHENTICATION);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setSpeculativeLoadingStatus(WebSettings, int)}
     * {@link WebSettingsCompat#getSpeculativeLoadingStatus(WebSettings)}
     */
    public static final ApiFeature.NoFramework SPECULATIVE_LOADING =
            new ApiFeature.NoFramework(WebViewFeature.SPECULATIVE_LOADING,
                    Features.SPECULATIVE_LOADING);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setBackForwardCacheEnabled(WebSettings, boolean)}
     * {@link WebSettingsCompat#getBackForwardCacheEnabled(WebSettings)}
     */
    public static final ApiFeature.NoFramework BACK_FORWARD_CACHE =
            new ApiFeature.NoFramework(WebViewFeature.BACK_FORWARD_CACHE,
                    Features.BACK_FORWARD_CACHE);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getBackForwardCacheSettings(WebSettings)}
     */
    public static final ApiFeature.NoFramework BACK_FORWARD_CACHE_SETTINGS =
            new ApiFeature.NoFramework(WebViewFeature.BACK_FORWARD_CACHE_SETTINGS,
                    Features.BACK_FORWARD_CACHE_SETTINGS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link BackForwardCacheSettings#setMaxPagesInCache(int)}
     * {@link BackForwardCacheSettings#setTimeoutSeconds(long)}
     */
    public static final ApiFeature.NoFramework BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3 =
            new ApiFeature.NoFramework(WebViewFeature.BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3,
                    Features.BACK_FORWARD_CACHE_SETTINGS_V3);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link BackForwardCacheSettings#setKeepForwardEntriesEnabled(boolean)}
     * {@link BackForwardCacheSettings#isKeepForwardEntriesEnabled()}
     */
    public static final ApiFeature.NoFramework BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V4 =
            new ApiFeature.NoFramework(WebViewFeature.BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V4,
                    Features.BACK_FORWARD_CACHE_SETTINGS_V4);

    public static final ApiFeature.NoFramework DELETE_BROWSING_DATA = new ApiFeature.NoFramework(
            WebViewFeature.DELETE_BROWSING_DATA, Features.WEB_STORAGE_DELETE_BROWSING_DATA
    );

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, PrefetchParameters, WebViewOutcomeReceiver)}
     * {@link androidx.webkit.PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, WebViewOutcomeReceiver)}
     */
    public static final ApiFeature.NoFramework PROFILE_URL_PREFETCH =
            new ApiFeature.NoFramework(WebViewFeature.PROFILE_URL_PREFETCH,
                    Features.PREFETCH_WITH_URL) {
                @Override
                public boolean isSupportedByWebView() {
                    // Multi-profile is a requirement for this feature.
                    if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                        return false;
                    }
                    return super.isSupportedByWebView();
                }
            };

    /**
     * Feature that is relevant for the implementation of
     * {@link androidx.webkit.WebViewCompat#startUpWebView(Context, WebViewStartUpConfig, WebViewOutcomeReceiver)}
     *
     * This feature is not referred to by the app and is only used by the library to choose
     * different code paths based on underlying support from WebView.
     */
    public static final ApiFeature.NoFrameworkInternal ASYNC_WEBVIEW_STARTUP_V2 =
            new ApiFeature.NoFrameworkInternal(Features.ASYNC_WEBVIEW_STARTUP_V2);


    /**
     * @deprecated Use {@link #ASYNC_WEBVIEW_STARTUP_V2} instead.
     * Feature that is relevant for the implementation of
     * {@link androidx.webkit.WebViewCompat#startUpWebView(Context, WebViewStartUpConfig, WebViewOutcomeReceiver)}
     *
     * This feature is not referred to by the app and is only used by the library to choose
     * different code paths based on underlying support from WebView.
     */
    @Deprecated
    public static final ApiFeature.NoFrameworkInternal ASYNC_WEBVIEW_STARTUP =
            new ApiFeature.NoFrameworkInternal(Features.ASYNC_WEBVIEW_STARTUP);

    /**
     * Feature that is relevant for the implementation of
     * {@link WebViewStartUpResult#getNonUiThreadBlockingStartUpLocations()}
     *
     * This feature is not referred to by the app and is only used by the library to choose
     * different code paths based on underlying support from WebView.
     */
    public static final ApiFeature.NoFrameworkInternal
            ASYNC_WEBVIEW_STARTUP_ASYNC_STARTUP_LOCATIONS =
            new ApiFeature.NoFrameworkInternal(
                    Features.ASYNC_WEBVIEW_STARTUP_ASYNC_STARTUP_LOCATIONS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link androidx.webkit.WebViewCompat#setDefaultTrafficStatsTag(int)}
     */
    public static final ApiFeature.NoFramework DEFAULT_TRAFFICSTATS_TAGGING =
            new ApiFeature.NoFramework(WebViewFeature.DEFAULT_TRAFFICSTATS_TAGGING,
                    Features.DEFAULT_TRAFFICSTATS_TAGGING);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#prerenderUrlAsync(WebView, String, CancellationSignal, Executor, PrerenderParameters, PrerenderOperationCallback)}
     */
    public static final ApiFeature.NoFramework PRERENDER_WITH_URL =
            new ApiFeature.NoFramework(WebViewFeature.PRERENDER_WITH_URL,
                    Features.PRERENDER_WITH_URL);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#setSpeculativeLoadingConfig(SpeculativeLoadingConfig)}
     */
    @SuppressWarnings({"deprecation", "removal"})
    public static final ApiFeature.NoFramework SPECULATIVE_LOADING_CONFIG =
            new ApiFeature.NoFramework(WebViewFeature.SPECULATIVE_LOADING_CONFIG,
                    Features.SPECULATIVE_LOADING_CONFIG);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link PrefetchCache#setMaxPrefetches(int)},
     * {@link PrefetchCache#setPrefetchTtlSeconds(int)}
     */
    public static final ApiFeature.NoFramework PREFETCH_CACHE =
            new ApiFeature.NoFramework(WebViewFeature.PREFETCH_CACHE_V1,
                    Features.PREFETCH_CACHE);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, WebViewOutcomeReceiver)},
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, PrefetchParameters, WebViewOutcomeReceiver)},
     * {@link PrefetchOperationCallbackWithResultAdapter#buildInvocationHandler(WebViewOutcomeReceiver)}
     *
     * This feature is not referred to by the app and is only used by the library to choose
     * different code paths based on underlying support from WebView.
     */
    public static final ApiFeature.NoFrameworkInternal PREFETCH_WITH_CALLBACK_RESULT =
            new ApiFeature.NoFrameworkInternal(Features.PREFETCH_WITH_CALLBACK_RESULT_V1);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link Profile#setMaxPrerenders(int)}
     */
    public static final ApiFeature.NoFramework SET_MAX_PRERENDERS =
            new ApiFeature.NoFramework(WebViewFeature.SET_MAX_PRERENDERS_V1,
                    Features.SET_MAX_PRERENDERS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#saveState}.
     */
    public static final ApiFeature.NoFramework SAVE_STATE =
            new ApiFeature.NoFramework(WebViewFeature.SAVE_STATE,
                    Features.SAVE_STATE);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link Navigation#getWebResourceError()}
     * {@link WebResourceErrorCompat#getDebugCode()}.
     */
    public static final ApiFeature.NoFramework NAVIGATION_GET_WEB_RESOURCE_ERROR =
            new ApiFeature.NoFramework(
                    WebViewFeature.NAVIGATION_GET_WEB_RESOURCE_ERROR,
                    Features.NAVIGATION_GET_WEB_RESOURCE_ERROR);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link NavigationListener#onNavigationStarted(Navigation)},
     * {@link NavigationListener#onNavigationRedirected(Navigation)},
     * {@link NavigationListener#onNavigationCompleted(Navigation)},
     * {@link NavigationListener#onPageDeleted(Page)},
     * {@link NavigationListener#onPageLoadEvent(Page)},
     * {@link NavigationListener#onPageDomContentLoadedEvent(Page)},
     * {@link NavigationListener#onFirstContentfulPaintMillis(Page, long)},
     * {@link NavigationListener#onLargestContentfulPaintMillis(Page, long)},
     * {@link NavigationListener#onPerformanceMarkMillis(Page, String, long)},
     * {@link Navigation#getPage()},
     * {@link Navigation#getUrl()},
     * {@link Navigation#wasInitiatedByPage()},
     * {@link Navigation#isSameDocument()},
     * {@link Navigation#isReload()},
     * {@link Navigation#isHistory()},
     * {@link Navigation#isBack()},
     * {@link Navigation#isForward()},
     * {@link Navigation#didCommit()},
     * {@link Navigation#didCommitErrorPage()},
     * {@link Navigation#getStatusCode()},
     * {@link Navigation#isRestore()},
     * {@link Page#getUrl()}
     * Note that we map to the last Chromium feature related to this set of apis that has
     * been released to stable at the time of this change, namely PAGE_GET_URL. This is to ensure
     * that the apis can still be used without needed to wait for a new feature from the Chromium
     * side to be added and released.
     */
    public static final ApiFeature.NoFramework NAVIGATION_LISTENER = new ApiFeature.NoFramework(
            WebViewFeature.NAVIGATION_LISTENER, Features.PAGE_GET_URL);


    /**
     * This is an internal only feature that indicate whether it is safe to cache WebView Provider
     * objects for the current WebView APK.
     */
    public static final ApiFeature.NoFramework PROVIDER_WEAKLY_REF_WEBVIEW =
            new ApiFeature.NoFramework(WebViewFeature.PROVIDER_WEAKLY_REF_WEBVIEW,
                    Features.PROVIDER_WEAKLY_REF_WEBVIEW);
    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link WebSettingsCompat#setPaymentRequestEnabled(WebSettings, boolean)},
     * {@link WebSettingsCompat#getPaymentRequestEnabled(WebSettings)},
     * {@link WebSettingsCompat#setHasEnrolledInstrumentEnabled(WebSettings, boolean)}, and
     * {@link WebSettingsCompat#getHasEnrolledInstrumentEnabled(WebSettings)}.
     */
    public static final ApiFeature.NoFramework PAYMENT_REQUEST =
            new ApiFeature.NoFramework(WebViewFeature.PAYMENT_REQUEST,
                    Features.PAYMENT_REQUEST);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers:
     * {@link androidx.webkit.WebViewBuilder#build(Context)}.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final ApiFeature.NoFramework WEBVIEW_BUILDER_V1 =
            new ApiFeature.NoFramework(WebViewFeature.WEBVIEW_BUILDER_EXPERIMENTAL_V1,
                    Features.WEBVIEW_BUILDER);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers:
     * {@link androidx.webkit.WebViewBuilder#applyTo(WebView)}.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final ApiFeature.NoFramework WEBVIEW_BUILDER_V2 =
            new ApiFeature.NoFramework(WebViewFeature.WEBVIEW_BUILDER_EXPERIMENTAL_V2,
                    Features.WEBVIEW_BUILDER_V2);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebResourceResponseCompat#setCookies(List)},
     * {@link WebSettingsCompat#setCookiesIncludedInShouldInterceptRequest(WebSettings, boolean)},
     * {@link WebSettingsCompat#areCookiesIncludedInShouldInterceptRequest(WebSettings)},
     * {@link ServiceWorkerWebSettingsCompat#setIncludeCookiesOnShouldInterceptRequestEnabled(boolean)}, and
     * {@link ServiceWorkerWebSettingsCompat#isIncludeCookiesOnShouldInterceptRequestEnabled()}.
     */
    public static final ApiFeature.NoFramework COOKIE_INTERCEPT = new ApiFeature.NoFramework(
            WebViewFeature.COOKIE_INTERCEPT, Features.COOKIE_INTERCEPT);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@code WebViewCompat#setShouldCacheProvider(boolean)}.
     */
    @Profile.ExperimentalWarmUpRendererProcess
    public static final ApiFeature.NoFramework WARM_UP_RENDERER_PROCESS =
            new ApiFeature.NoFramework(WebViewFeature.WARM_UP_RENDERER_PROCESS,
                    Features.WARM_UP_RENDERER_PROCESS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     *
     * <p>This feature covers
     * {@link Profile#addCustomHeader(androidx.webkit.CustomHeader)},
     * {@link Profile#hasCustomHeader(String)},
     * {@link Profile#getCustomHeaders()},
     * {@link Profile#getCustomHeaders(String)},
     * {@link Profile#getCustomHeaders(String, String)},
     * {@link Profile#clearCustomHeader(String)},
     * {@link Profile#clearCustomHeader(String, String)}, and
     * {@link Profile#clearAllCustomHeaders()}.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final ApiFeature.NoFramework CUSTOM_REQUEST_HEADERS =
            new ApiFeature.NoFramework(WebViewFeature.CUSTOM_REQUEST_HEADERS,
                    Features.CUSTOM_REQUEST_HEADERS);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link WebViewStartUpConfig.Builder#setProfilesToLoadDuringStartup(Set)},
     */
    public static final StartupApiFeature.NoFramework STARTUP_FEATURE_SET_PROFILES_TO_LOAD =
            new StartupApiFeature.NoFramework(WebViewFeature.STARTUP_FEATURE_SET_PROFILES_TO_LOAD,
                    StartupFeatures.STARTUP_FEATURE_SET_PROFILES_TO_LOAD);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.ProcessGlobalConfig#setUiThreadStartupMode(Context, int)}.
     *
     * @deprecated Use {@link #STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2} instead.
     */
    @WebViewCompat.ExperimentalAsyncStartUp
    @Deprecated
    public static final StartupApiFeature.NoFramework
            STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE =
            new StartupApiFeature.NoFramework(
                    WebViewFeature.STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE,
                    StartupFeatures.STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.ProcessGlobalConfig#setUiThreadStartupMode(Context, int)}.
     */
    @WebViewCompat.ExperimentalAsyncStartUp
    public static final StartupApiFeature.NoFramework
            STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2 =
            new StartupApiFeature.NoFramework(
                    WebViewFeature.STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2,
                    StartupFeatures.STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link Profile#preconnect(String)}
     */
    public static final ApiFeature.NoFramework PRECONNECT =
            new ApiFeature.NoFramework(WebViewFeature.PRECONNECT,
                    Features.PRECONNECT);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link Profile#enqueuePreconnect(String)}
     */
    public static final ApiFeature.NoFramework ENQUEUE_PRECONNECT =
            new ApiFeature.NoFramework(WebViewFeature.ENQUEUE_PRECONNECT,
                    Features.ENQUEUE_PRECONNECT);


    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link Profile#addQuicHints(Set)}
     */
    public static final ApiFeature.NoFramework ADD_QUIC_HINTS_V1 =
            new ApiFeature.NoFramework(WebViewFeature.ADD_QUIC_HINTS_V1,
                    Features.ADD_QUIC_HINTS_V1);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setHyperlinkContextMenuItems(WebSettings, int)},
     */
    public static final ApiFeature.NoFramework HYPERLINK_CONTEXT_MENU_ITEMS =
            new ApiFeature.NoFramework(WebViewFeature.HYPERLINK_CONTEXT_MENU_ITEMS,
                    Features.HYPERLINK_CONTEXT_MENU_ITEMS);

    /**
     * This feature covers {@link
     * androidx.webkit.WebViewCompat#addJavaScriptOnEvent(android.webkit.WebView, String, int, Set,
     * androidx.webkit.JavaScriptExecutionWorld)} {@link
     * androidx.webkit.WebViewCompat#getExecutionWorld(android.webkit.WebView, String)} {@link
     * androidx.webkit.WebViewCompat#addWebMessageListener(WebView, String, Set, JavaScriptExecutionWorld, WebViewCompat.WebMessageListener)
     * } {@link
     * androidx.webkit.WebViewCompat#removeWebMessageListener(WebView, JavaScriptExecutionWorld, String)
     * }
     */
    public static final ApiFeature.NoFramework JS_INJECTION_IN_FRAME_AND_WORLD =
            new ApiFeature.NoFramework(
                    WebViewFeature.JS_INJECTION_IN_FRAME_AND_WORLD,
                    Features.JS_INJECTION_IN_FRAME_AND_WORLD);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers:
     * {@link WebViewCompat#navigate(WebView, String, NavigationParameters)}.
     */
    public static final ApiFeature.NoFramework WEBVIEW_NAVIGATE_V1 =
            new ApiFeature.NoFramework(WebViewFeature.WEBVIEW_NAVIGATE_EXPERIMENTAL_V1,
                    Features.WEBVIEW_NAVIGATE_V1);

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers:
     * {@link WebSettingsCompat#setDownloadFaviconsEnabled(WebSettings, boolean)}
     * {@link WebSettingsCompat#getDownloadFaviconsEnabled(WebSettings)}
     */
    public static final ApiFeature.NoFramework DOWNLOAD_FAVICONS_ENABLED =
            new ApiFeature.NoFramework(
                    WebViewFeature.DOWNLOAD_FAVICONS_ENABLED,
                    Features.DOWNLOAD_FAVICONS_ENABLED);

    /**
     * This feature covers
     * {@link Profile#getHttpCache()}
     * {@link androidx.webkit.HttpCache#getDefaultQuotaBytes()}
     * {@link androidx.webkit.HttpCache#isUsingDefaultQuota()}
     * {@link androidx.webkit.HttpCache#useDefaultQuota()}
     * {@link androidx.webkit.HttpCache#getQuotaBytes()}
     * {@link androidx.webkit.HttpCache#setQuotaBytes(long)}
     */
    public static final ApiFeature.NoFramework HTTP_CACHE_MANAGER =
            new ApiFeature.NoFramework(WebViewFeature.HTTP_CACHE_MANAGER,
                    Features.HTTP_CACHE_MANAGER);

    // --- Add new feature constants above this line ---

    private WebViewFeatureInternal() {
        // Class should not be instantiated
    }

    /**
     * Return whether a public feature is supported by any internal features defined in this class.
     */
    public static boolean isSupported(
            @WebViewFeature.WebViewSupportFeature @NonNull String publicFeatureValue) {
        return isSupported(publicFeatureValue, ApiFeature.values());
    }

    /**
     * Return whether a public startup feature is supported by any internal features defined in
     * this class.
     */
    public static boolean isStartupFeatureSupported(
            @WebViewFeature.WebViewStartupFeature @NonNull String publicFeatureValue,
            @NonNull Context context) {
        return isStartupFeatureSupported(publicFeatureValue, StartupApiFeature.values(), context);
    }

    /**
     * Return whether a public feature is supported by any {@link ConditionallySupportedFeature}s
     * defined in {@code internalFeatures}.
     *
     * @throws RuntimeException if {@code publicFeatureValue} is not matched in
     *                          {@code internalFeatures}
     */
    @VisibleForTesting
    public static <T extends ConditionallySupportedFeature> boolean isSupported(
            @WebViewFeature.WebViewSupportFeature @NonNull String publicFeatureValue,
            @NonNull Collection<T> internalFeatures) {
        Set<ConditionallySupportedFeature> matchingFeatures = new HashSet<>();
        for (ConditionallySupportedFeature feature : internalFeatures) {
            if (feature.getPublicFeatureName().equals(publicFeatureValue)) {
                matchingFeatures.add(feature);
            }
        }
        if (matchingFeatures.isEmpty()) {
            throw new RuntimeException("Unknown feature " + publicFeatureValue);
        }
        for (ConditionallySupportedFeature feature : matchingFeatures) {
            if (feature.isSupported()) return true;
        }
        return false;
    }

    /**
     * Return whether a public startup feature is supported by any {@link StartupApiFeature}s
     * defined in {@code internalFeatures}.
     *
     * @throws RuntimeException if {@code publicFeatureValue} is not matched in
     *                          {@code internalFeatures}
     */
    @VisibleForTesting
    public static boolean isStartupFeatureSupported(
            @WebViewFeature.WebViewStartupFeature @NonNull String publicFeatureValue,
            @NonNull Collection<StartupApiFeature> internalFeatures, @NonNull Context context) {
        Set<StartupApiFeature> matchingFeatures = new HashSet<>();
        for (StartupApiFeature feature : internalFeatures) {
            if (feature.getPublicFeatureName().equals(publicFeatureValue)) {
                matchingFeatures.add(feature);
            }
        }
        if (matchingFeatures.isEmpty()) {
            throw new RuntimeException("Unknown feature " + publicFeatureValue);
        }
        for (StartupApiFeature feature : matchingFeatures) {
            if (feature.isSupported(context)) return true;
        }
        return false;
    }

    /**
     * Utility method for throwing an exception explaining that the feature the app trying to use
     * isn't supported.
     */
    public static @NonNull UnsupportedOperationException getUnsupportedOperationException() {
        return new UnsupportedOperationException("This method is not supported by the current "
                + "version of the framework and the current WebView APK");
    }
}
