/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.webkit;

import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.IntDef;
import androidx.annotation.RequiresFeature;
import androidx.annotation.RequiresOptIn;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;
import androidx.webkit.internal.ApiFeature;
import androidx.webkit.internal.ApiHelperForN;
import androidx.webkit.internal.ApiHelperForO;
import androidx.webkit.internal.ApiHelperForQ;
import androidx.webkit.internal.WebSettingsAdapter;
import androidx.webkit.internal.WebSettingsNoOpAdapter;
import androidx.webkit.internal.WebViewFeatureInternal;
import androidx.webkit.internal.WebViewGlueCommunicator;

import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;
import org.jspecify.annotations.NonNull;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Compatibility version of {@link android.webkit.WebSettings}
 */
public class WebSettingsCompat {

    private static final String TAG = "WebSettingsCompat";

    private WebSettingsCompat() {
    }

    /**
     * Sets whether this WebView should raster tiles when it is
     * offscreen but attached to a window. Turning this on can avoid
     * rendering artifacts when animating an offscreen WebView on-screen.
     * Offscreen WebViews in this mode use more memory. The default value is
     * false.<br>
     * Please follow these guidelines to limit memory usage:
     * <ul>
     * <li> WebView size should be not be larger than the device screen size.
     * <li> Limit use of this mode to a small number of WebViews. Use it for
     *   visible WebViews and WebViews about to be animated to visible.
     * </ul>
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#OFF_SCREEN_PRERASTER} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.OFF_SCREEN_PRERASTER,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setOffscreenPreRaster(@NonNull WebSettings settings, boolean enabled) {
        settings.setOffscreenPreRaster(enabled);
    }

    /**
     * Gets whether this WebView should raster tiles when it is
     * offscreen but attached to a window.
     *
     * @return {@code true} if this WebView will raster tiles when it is
     * offscreen but attached to a window.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#OFF_SCREEN_PRERASTER} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.OFF_SCREEN_PRERASTER,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getOffscreenPreRaster(@NonNull WebSettings settings) {
        return settings.getOffscreenPreRaster();
    }

    /**
     * Sets whether Safe Browsing is enabled. Safe Browsing allows WebView to
     * protect against malware and phishing attacks by verifying the links.
     *
     * <p>
     * Safe Browsing can be disabled for all WebViews using a manifest tag (read <a
     * href="{@docRoot}reference/android/webkit/WebView.html">general Safe Browsing info</a>). The
     * manifest tag has a lower precedence than this API.
     *
     * <p>
     * Safe Browsing is enabled by default for devices which support it.
     *
     * @param settings The WebSettings object to update.
     * @param enabled  Whether Safe Browsing is enabled.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SAFE_BROWSING_ENABLE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SAFE_BROWSING_ENABLE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setSafeBrowsingEnabled(@NonNull WebSettings settings, boolean enabled) {
        ApiFeature.O feature = WebViewFeatureInternal.SAFE_BROWSING_ENABLE;
        if (feature.isSupportedByFramework()) {
            ApiHelperForO.setSafeBrowsingEnabled(settings, enabled);
        } else if (feature.isSupportedByWebView()) {
            getAdapter(settings).setSafeBrowsingEnabled(enabled);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Gets whether Safe Browsing is enabled.
     * See {@link #setSafeBrowsingEnabled}.
     *
     * @return {@code true} if Safe Browsing is enabled and {@code false} otherwise.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SAFE_BROWSING_ENABLE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SAFE_BROWSING_ENABLE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getSafeBrowsingEnabled(@NonNull WebSettings settings) {
        ApiFeature.O feature = WebViewFeatureInternal.SAFE_BROWSING_ENABLE;
        if (feature.isSupportedByFramework()) {
            return ApiHelperForO.getSafeBrowsingEnabled(settings);
        } else if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getSafeBrowsingEnabled();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     *
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    @IntDef(flag = true, value = {
            WebSettings.MENU_ITEM_NONE,
            WebSettings.MENU_ITEM_SHARE,
            WebSettings.MENU_ITEM_WEB_SEARCH,
            WebSettings.MENU_ITEM_PROCESS_TEXT
    })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.PARAMETER, ElementType.METHOD})
    public @interface MenuItemFlags {
    }

    /**
     * Disables the action mode menu items according to {@code menuItems} flag.
     *
     * @param settings  The WebSettings object to update.
     * @param menuItems an integer field flag for the menu items to be disabled.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#DISABLED_ACTION_MODE_MENU_ITEMS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.DISABLED_ACTION_MODE_MENU_ITEMS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setDisabledActionModeMenuItems(@NonNull WebSettings settings,
            @MenuItemFlags int menuItems) {
        ApiFeature.N feature = WebViewFeatureInternal.DISABLED_ACTION_MODE_MENU_ITEMS;
        if (feature.isSupportedByFramework()) {
            ApiHelperForN.setDisabledActionModeMenuItems(settings, menuItems);
        } else if (feature.isSupportedByWebView()) {
            getAdapter(settings).setDisabledActionModeMenuItems(menuItems);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Gets the action mode menu items that are disabled, expressed in an integer field flag.
     * The default value is {@link WebSettings#MENU_ITEM_NONE}
     *
     * @return all the disabled menu item flags combined with bitwise OR.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#DISABLED_ACTION_MODE_MENU_ITEMS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.DISABLED_ACTION_MODE_MENU_ITEMS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static @MenuItemFlags int getDisabledActionModeMenuItems(@NonNull WebSettings settings) {
        ApiFeature.N feature = WebViewFeatureInternal.DISABLED_ACTION_MODE_MENU_ITEMS;
        if (feature.isSupportedByFramework()) {
            return ApiHelperForN.getDisabledActionModeMenuItems(settings);
        } else if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getDisabledActionModeMenuItems();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Disable force dark, irrespective of the force dark mode of the WebView parent. In this mode,
     * WebView content will always be rendered as-is, regardless of whether native views are being
     * automatically darkened.
     *
     * @see #setForceDark
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int FORCE_DARK_OFF = WebSettings.FORCE_DARK_OFF;

    /**
     * Enable force dark dependent on the state of the WebView parent view. If the WebView parent
     * view is being automatically force darkened
     * (@see android.view.View#setForceDarkAllowed), then WebView content will be rendered
     * so as to emulate a dark theme. WebViews that are not attached to the view hierarchy will not
     * be inverted.
     *
     * <p class="note"> If your app uses a dark theme, WebView will not be inverted. Similarly, if
     * your app's theme inherits from a {@code DayNight} theme, WebView will not be inverted.
     * In either of these cases, you should control the mode manually with
     * {@link ForceDark#FORCE_DARK_ON} or {@link ForceDark#FORCE_DARK_OFF}.
     *
     * <p> See
     * <a href="https://developer.android.com/guide/topics/ui/look-and-feel/darktheme#force_dark">
     * Force Dark documentation</a> for more information.
     *
     * @see #setForceDark
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int FORCE_DARK_AUTO = WebSettings.FORCE_DARK_AUTO;

    /**
     * Unconditionally enable force dark. In this mode WebView content will always be rendered so
     * as to emulate a dark theme.
     *
     * @see #setForceDark
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int FORCE_DARK_ON = WebSettings.FORCE_DARK_ON;

    /**
     *
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    @IntDef(value = {
            FORCE_DARK_OFF,
            FORCE_DARK_AUTO,
            FORCE_DARK_ON,
    })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.PARAMETER, ElementType.METHOD})
    public @interface ForceDark {
    }

    /**
     * Set the force dark mode for this WebView.
     *
     *
     * <p>
     * If equals to {@link ForceDark#FORCE_DARK_ON} then {@link #setForceDarkStrategy} is used to
     * specify darkening strategy.
     *
     * @param forceDarkMode the force dark mode to set.
     * @see #getForceDark
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#FORCE_DARK} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated The "force dark" model previously implemented by WebView was complex
     * and didn't interoperate well with current Web standards for
     * {@code prefers-color-scheme} and {@code color-scheme}. In apps with
     * {@code targetSdkVersion} &ge; {@link android.os.Build.VERSION_CODES#TIRAMISU}
     * this API is a no-op and WebView will always use the dark style defined by web content
     * authors if the app's theme is dark. To customize the behavior, refer to
     * {@link #setAlgorithmicDarkeningAllowed}.
     */
    @Deprecated
    @RequiresFeature(name = WebViewFeature.FORCE_DARK,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setForceDark(@NonNull WebSettings settings,
            @ForceDark int forceDarkMode) {
        ApiFeature.Q feature = WebViewFeatureInternal.FORCE_DARK;
        if (feature.isSupportedByFramework()) {
            ApiHelperForQ.setForceDark(settings, forceDarkMode);
        } else if (feature.isSupportedByWebView()) {
            getAdapter(settings).setForceDark(forceDarkMode);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the force dark mode for this WebView.
     *
     * <p>
     * The default force dark mode is {@link #FORCE_DARK_AUTO}.
     *
     * @return the currently set force dark mode.
     * @see #setForceDark
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#FORCE_DARK} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    @RequiresFeature(name = WebViewFeature.FORCE_DARK,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static @ForceDark int getForceDark(@NonNull WebSettings settings) {
        ApiFeature.Q feature = WebViewFeatureInternal.FORCE_DARK;
        if (feature.isSupportedByFramework()) {
            return ApiHelperForQ.getForceDark(settings);
        } else if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getForceDark();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Control whether algorithmic darkening is allowed.
     *
     * <p class="note">
     * <b>Note:</b> This API and the behaviour described only apply to apps with
     * {@code targetSdkVersion} &ge; {@link android.os.Build.VERSION_CODES#TIRAMISU}.
     *
     * <p>
     * WebView always sets the media query {@code prefers-color-scheme} according to the app's
     * theme attribute {@code android.R.styleable#Theme_isLightTheme isLightTheme}, i.e.
     * {@code prefers-color-scheme} is {@code light} if isLightTheme is true or not specified,
     * otherwise it is {@code dark}. This means that the web content's light or dark style will
     * be applied automatically to match the app's theme if the content supports it.
     *
     * <p>
     * Algorithmic darkening is disallowed by default.
     * <p>
     * If the app's theme is dark and it allows algorithmic darkening, WebView will attempt to
     * darken web content using an algorithm, if the content doesn't define its own dark styles
     * and doesn't explicitly disable darkening.
     *
     * <p>
     * If Android is applying Force Dark to WebView then WebView will ignore the value of
     * this setting and behave as if it were set to true.
     *
     * <p>
     * The deprecated {@link #setForceDark} and related API are no-ops in apps with
     * {@code targetSdkVersion} &ge; {@link android.os.Build.VERSION_CODES#TIRAMISU},
     * but they still apply to apps with
     * {@code targetSdkVersion} &lt; {@link android.os.Build.VERSION_CODES#TIRAMISU}.
     *
     * <p>
     * The below table summarizes how APIs work with different apps.
     *
     * <table border="2" width="85%" align="center" cellpadding="5">
     *     <thead>
     *         <tr>
     *             <th>App</th>
     *             <th>Web content which uses prefers-color-scheme</th>
     *             <th>Web content which does not use prefers-color-scheme</th>
     *         </tr>
     *     </thead>
     *     <tbody>
     *     <tr>
     *         <td>App with {@code isLightTheme} True or not set</td>
     *         <td>Renders with the light theme defined by the content author.</td>
     *         <td>Renders with the default styling defined by the content author.</td>
     *     </tr>
     *     <tr>
     *         <td>App with Android forceDark in effect</td>
     *         <td>Renders with the dark theme defined by the content author.</td>
     *         <td>Renders with the styling modified to dark colors by an algorithm
     *             if allowed by the content author.</td>
     *     </tr>
     *     <tr>
     *         <td>App with {@code isLightTheme} False,
     *            {@code targetSdkVersion} &lt; {@link android.os.Build.VERSION_CODES#TIRAMISU},
     *             and has {@code FORCE_DARK_AUTO}</td>
     *         <td>Renders with the dark theme defined by the content author.</td>
     *         <td>Renders with the default styling defined by the content author.</td>
     *     </tr>
     *     <tr>
     *         <td>App with {@code isLightTheme} False,
     *            {@code targetSdkVersion} &ge; {@link android.os.Build.VERSION_CODES#TIRAMISU},
     *             and {@code setAlgorithmicDarkening(false)}</td>
     *         <td>Renders with the dark theme defined by the content author.</td>
     *         <td>Renders with the default styling defined by the content author.</td>
     *     </tr>
     *     <tr>
     *         <td>App with {@code isLightTheme} False,
     *            {@code targetSdkVersion} &ge; {@link android.os.Build.VERSION_CODES#TIRAMISU},
     *             and {@code setAlgorithmicDarkening(true)}</td>
     *         <td>Renders with the dark theme defined by the content author.</td>
     *         <td>Renders with the styling modified to dark colors by an algorithm if allowed
     *             by the content author.</td>
     *     </tr>
     *     </tbody>
     * </table>
     * </p>
     *
     * @param settings The WebSettings object to update.
     * @param allow    allow algorithmic darkening or not.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ALGORITHMIC_DARKENING} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ALGORITHMIC_DARKENING,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setAlgorithmicDarkeningAllowed(@NonNull WebSettings settings,
            boolean allow) {
        ApiFeature.T feature = WebViewFeatureInternal.ALGORITHMIC_DARKENING;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setAlgorithmicDarkeningAllowed(allow);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get if algorithmic darkening is allowed or not for this WebView.
     * The default is false.
     *
     * @return if the algorithmic darkening is allowed or not.
     * @see #setAlgorithmicDarkeningAllowed
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ALGORITHMIC_DARKENING} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ALGORITHMIC_DARKENING,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean isAlgorithmicDarkeningAllowed(@NonNull WebSettings settings) {
        ApiFeature.T feature = WebViewFeatureInternal.ALGORITHMIC_DARKENING;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).isAlgorithmicDarkeningAllowed();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * In this mode WebView content will be darkened by a user agent and it will ignore the
     * web page's dark theme if it exists. To avoid mixing two different darkening strategies,
     * the {@code prefers-color-scheme} media query will evaluate to light.
     *
     * <p> See <a href="https://drafts.csswg.org/css-color-adjust-1/">specification</a>
     * for more information.
     *
     * @see #setForceDarkStrategy
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int DARK_STRATEGY_USER_AGENT_DARKENING_ONLY =
            WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY;

    /**
     * In this mode WebView content will always be darkened using dark theme provided by web page.
     * If web page does not provide dark theme support WebView content will be rendered with a
     * default theme.
     *
     * <p> See <a href="https://drafts.csswg.org/css-color-adjust-1/">specification</a>
     * for more information.
     *
     * @see #setForceDarkStrategy
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int DARK_STRATEGY_WEB_THEME_DARKENING_ONLY =
            WebSettingsBoundaryInterface.ForceDarkBehavior.MEDIA_QUERY_ONLY;

    /**
     * In this mode WebView content will be darkened by a user agent unless web page supports dark
     * theme. WebView determines whether web pages supports dark theme by the presence of
     * {@code color-scheme} metadata containing "dark" value. For example,
     * {@code <meta name="color-scheme" content="dark light">}.
     * If the metadata is not presented WebView content will be darkened by a user agent and
     * {@code prefers-color-scheme} media query will evaluate to light.
     *
     * <p> See <a href="https://drafts.csswg.org/css-color-adjust-1/">specification</a>
     * for more information.
     *
     * @see #setForceDarkStrategy
     * @deprecated refer to {@link #setForceDark}
     */
    @Deprecated
    public static final int DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING =
            WebSettingsBoundaryInterface.ForceDarkBehavior.PREFER_MEDIA_QUERY_OVER_FORCE_DARK;

    /**
     *
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    @IntDef(value = {
            DARK_STRATEGY_USER_AGENT_DARKENING_ONLY,
            DARK_STRATEGY_WEB_THEME_DARKENING_ONLY,
            DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING,
    })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.PARAMETER, ElementType.METHOD})
    public @interface ForceDarkStrategy {
    }

    /**
     * Set how WebView content should be darkened.
     *
     *
     * <p>
     * The specified strategy is only used if force dark mode is on.
     * See {@link #setForceDark}.
     *
     * @param forceDarkBehavior the force dark strategy to set.
     * @see #getForceDarkStrategy
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#FORCE_DARK_STRATEGY} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated refer to {@link #setForceDark}
     */
    @RequiresFeature(name = WebViewFeature.FORCE_DARK_STRATEGY,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @Deprecated
    public static void setForceDarkStrategy(@NonNull WebSettings settings,
            @ForceDarkStrategy int forceDarkBehavior) {
        ApiFeature.NoFramework feature = WebViewFeatureInternal.FORCE_DARK_STRATEGY;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setForceDarkStrategy(forceDarkBehavior);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get how content is darkened for this WebView.
     *
     * <p>
     * The default force dark strategy is
     * {@link #DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING}
     *
     * @return the currently set force dark strategy.
     * @see #setForceDarkStrategy
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#FORCE_DARK_STRATEGY} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated refer to {@link #setForceDark}
     */
    @RequiresFeature(name = WebViewFeature.FORCE_DARK_STRATEGY,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @Deprecated
    public static @ForceDarkStrategy int getForceDarkStrategy(@NonNull WebSettings settings) {
        ApiFeature.NoFramework feature = WebViewFeatureInternal.FORCE_DARK_STRATEGY;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getForceDark();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Sets whether EnterpriseAuthenticationAppLinkPolicy if set by admin is allowed to have any
     * effect on WebView.
     * <p>
     * EnterpriseAuthenticationAppLinkPolicy in WebView allows admins to specify authentication
     * urls. When WebView is redirected to authentication url, and an app on the device has
     * registered as the default handler for the url, that app is launched.
     * <p>
     * EnterpriseAuthenticationAppLinkPolicy is enabled by default.
     *
     * <p> See
     * <a href="https://source.chromium.org/chromium/chromium/src/+/main:components/policy/resources/policy_templates.json;l=32321?q=EnterpriseAuthenticationAppLinkPolicy%20file:policy_templates.json">
     * this</a> for more information on EnterpriseAuthenticationAppLinkPolicy.
     *
     * @param settings The WebSettings object to update.
     * @param enabled  Whether EnterpriseAuthenticationAppLinkPolicy should be enabled.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY} feature is not
     *     supported. This should be checked before use with
     *     {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setEnterpriseAuthenticationAppLinkPolicyEnabled(
            @NonNull WebSettings settings,
            boolean enabled) {
        ApiFeature.NoFramework feature =
                WebViewFeatureInternal.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setEnterpriseAuthenticationAppLinkPolicyEnabled(enabled);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Gets whether EnterpriseAuthenticationAppLinkPolicy is allowed to have any effect on WebView.
     *
     * <p> See
     * <a href="https://source.chromium.org/chromium/chromium/src/+/main:components/policy/resources/policy_templates.json;l=32321?q=EnterpriseAuthenticationAppLinkPolicy%20file:policy_templates.json">
     * this</a> for more information on EnterpriseAuthenticationAppLinkPolicy.
     *
     * @return {@code true} if EnterpriseAuthenticationAppLinkPolicy is enabled and {@code false}
     * otherwise.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY} feature is not
     *     supported. This should be checked before use with
     *     {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getEnterpriseAuthenticationAppLinkPolicyEnabled(
            @NonNull WebSettings settings) {
        ApiFeature.NoFramework feature =
                WebViewFeatureInternal.ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getEnterpriseAuthenticationAppLinkPolicyEnabled();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the currently configured allow-list of origins, which is guaranteed to receive the
     * {@code X-Requested-With} HTTP header on requests from the {@link WebView} owning the passed
     * {@link WebSettings}.
     * <p>
     * Any origin <em>not</em> on this allow-list may not receive the header, depending on the
     * current installed WebView provider.
     * <p>
     * The format of the strings in the allow-list follows the origin rules of
     * {@link WebViewCompat#addWebMessageListener(WebView, String, Set, WebViewCompat.WebMessageListener)}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return The configured set of allow-listed origins.
     * @see #setRequestedWithHeaderOriginAllowList(WebSettings, Set)
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#REQUESTED_WITH_HEADER_ALLOW_LIST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated The origin trial to disable the X-Requested-With feature has ended, so this
     * API now just returns an empty set.
     */
    @RequiresFeature(name = WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @Deprecated(forRemoval = true)
    @SuppressWarnings("removal")
    public static @NonNull Set<String> getRequestedWithHeaderOriginAllowList(
            @NonNull WebSettings settings) {
        return Collections.emptySet();
    }

    /**
     * Set an allow-list of origins to receive the {@code X-Requested-With} HTTP header from the
     * WebView owning the passed {@link WebSettings}.
     * <p>
     * Historically, this header was sent on all requests from WebView, containing the
     * app package name of the embedding app. Depending on the version of installed WebView, this
     * may no longer be the case, as the header was deprecated in late 2022, and its use
     * discontinued.
     * <p>
     * Apps can use this method to restore the legacy behavior for servers that still rely on
     * the deprecated header, but it should not be used to identify the WebView to first-party
     * servers under the control of the app developer.
     * <p>
     * The format of the strings in the allow-list follows the origin rules of
     * {@link WebViewCompat#addWebMessageListener(WebView, String, Set, WebViewCompat.WebMessageListener)}.
     *
     * @param settings  Settings retrieved from {@link WebView#getSettings()}.
     * @param allowList Set of origins to allow-list.
     * @throws IllegalArgumentException if the allow-list contains a malformed origin.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#REQUESTED_WITH_HEADER_ALLOW_LIST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated The origin trial to disable the X-Requested-With feature has ended, so this
     * API no longer does anything.
     */
    @RequiresFeature(name = WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @Deprecated(forRemoval = true)
    @SuppressWarnings("removal")
    public static void setRequestedWithHeaderOriginAllowList(@NonNull WebSettings settings,
            @NonNull Set<String> allowList) {
    }

    /**
     * Sets the WebView's user-agent metadata to generate user-agent client hints.
     * <p>
     * UserAgentMetadata in WebView is used to populate user-agent client hints, they can provide
     * the client’s branding and version information, the underlying operating system’s branding
     * and major version, as well as details about the underlying device.
     * <p>
     * The user-agent string can be set with {@link WebSettings#setUserAgentString(String)}, here
     * are the details on how this API interacts it to generate user-agent client hints.
     * <p>
     * If the UserAgentMetadata is null and the overridden user-agent contains the system default
     * user-agent, the system default value will be used.
     * <p>
     * If the UserAgentMetadata is null but the overridden user-agent doesn't contain the system
     * default user-agent, only the
     * <a href="https://wicg.github.io/client-hints-infrastructure/#low-entropy-hint-table">low-entry user-agent client hints</a> will be generated.
     *
     * <p> See <a href="https://wicg.github.io/ua-client-hints/">
     * this</a> for more information about User-Agent Client Hints.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param metadata the WebView's user-agent metadata.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#USER_AGENT_METADATA} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.USER_AGENT_METADATA,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setUserAgentMetadata(@NonNull WebSettings settings,
            @NonNull UserAgentMetadata metadata) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.USER_AGENT_METADATA;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setUserAgentMetadata(metadata);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the WebView's user-agent metadata which used to generate user-agent client hints.
     *
     * <p> See <a href="https://wicg.github.io/ua-client-hints/"> this</a> for more information
     * about User-Agent Client Hints.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#USER_AGENT_METADATA} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.USER_AGENT_METADATA,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static @NonNull UserAgentMetadata getUserAgentMetadata(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.USER_AGENT_METADATA;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getUserAgentMetadata();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    @IntDef({ATTRIBUTION_BEHAVIOR_DISABLED,
            ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_WEB_TRIGGER,
            ATTRIBUTION_BEHAVIOR_WEB_SOURCE_AND_WEB_TRIGGER,
            ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_APP_TRIGGER})
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Retention(RetentionPolicy.SOURCE)
    @interface AttributionRegistrationBehavior {
    }

    /**
     * AttributionRegistrationBehavior that disables source and trigger registration from WebView.
     * <p>
     * Note that the initial network call to the Attribution Source or Trigger URIs may still
     * happen depending on the installed version of WebView, but any response is discarded and
     * nothing will be stored on the device.
     */
    public static final int ATTRIBUTION_BEHAVIOR_DISABLED =
            WebSettingsBoundaryInterface.AttributionBehavior.DISABLED;
    /**
     * AttributionRegistrationBehavior that allows apps to register app sources (sources
     * associated with the app package name) and web triggers (triggers associated with the
     * eTLD+1) from WebView.
     * <p>
     * This is the default behavior.
     */
    public static final int ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_WEB_TRIGGER =
            WebSettingsBoundaryInterface.AttributionBehavior.APP_SOURCE_AND_WEB_TRIGGER;
    /**
     * AttributionRegistrationBehavior that allows apps to register web sources and web triggers
     * from WebView.
     * <p>
     * This option should only be used after applying to
     * <a href="https://developer.android.com/design-for-safety/privacy-sandbox/attribution-app-to-web#register-attribution">
     * use web sources</a>.
     */
    public static final int ATTRIBUTION_BEHAVIOR_WEB_SOURCE_AND_WEB_TRIGGER =
            WebSettingsBoundaryInterface.AttributionBehavior.WEB_SOURCE_AND_WEB_TRIGGER;
    /**
     * AttributionRegistrationBehavior that allows apps to register app sources and app triggers
     * from WebView.
     */
    public static final int ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_APP_TRIGGER =
            WebSettingsBoundaryInterface.AttributionBehavior.APP_SOURCE_AND_APP_TRIGGER;

    /**
     * Control how WebView interacts with
     * <a href="https://developer.android.com/design-for-safety/privacy-sandbox/attribution">Attribution Reporting</a>.
     * <p>
     * WebView supports
     * <a href="https://github.com/WICG/attribution-reporting-api">Attribution Reporting</a> across
     * <a href="https://developer.android.com/design-for-safety/privacy-sandbox/attribution-app-to-web">apps and web pages</a>
     * by enabling the web content to register sources and triggers.
     * <p>
     * By default, attribution sources will be registered as attributed to the app, while
     * triggers are attributed to the loaded web content
     * ({@link #ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_WEB_TRIGGER}). Apps should only need to
     * change this default if they have a specific semantic for how they use WebView. In
     * particular, in-app browsers should follow the steps to apply to the
     * <a href="https://developer.android.com/design-for-safety/privacy-sandbox/attribution-app-to-web#register-attribution">
     * allowlist for registering web sources</a> and then set the
     * {@link #ATTRIBUTION_BEHAVIOR_WEB_SOURCE_AND_WEB_TRIGGER} behavior.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param behavior New behavior to use.
     * @see
     * <a href="https://developer.android.com/design-for-safety/privacy-sandbox/attribution-app-to-web#register-attribution">How to apply to use web source</a>
     * @see #ATTRIBUTION_BEHAVIOR_DISABLED
     * @see #ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_WEB_TRIGGER
     * @see #ATTRIBUTION_BEHAVIOR_WEB_SOURCE_AND_WEB_TRIGGER
     * @see #ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_APP_TRIGGER
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ATTRIBUTION_REGISTRATION_BEHAVIOR} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ATTRIBUTION_REGISTRATION_BEHAVIOR,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setAttributionRegistrationBehavior(@NonNull WebSettings settings,
            @AttributionRegistrationBehavior int behavior) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.ATTRIBUTION_REGISTRATION_BEHAVIOR;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setAttributionRegistrationBehavior(behavior);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Read the current behavior for attribution registration.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @see #setAttributionRegistrationBehavior(WebSettings, int)
     * @see #ATTRIBUTION_BEHAVIOR_DISABLED
     * @see #ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_WEB_TRIGGER
     * @see #ATTRIBUTION_BEHAVIOR_WEB_SOURCE_AND_WEB_TRIGGER
     * @see #ATTRIBUTION_BEHAVIOR_APP_SOURCE_AND_APP_TRIGGER
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ATTRIBUTION_REGISTRATION_BEHAVIOR} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ATTRIBUTION_REGISTRATION_BEHAVIOR,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @AttributionRegistrationBehavior
    public static int getAttributionRegistrationBehavior(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.ATTRIBUTION_REGISTRATION_BEHAVIOR;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getAttributionRegistrationBehavior();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Sets permissions provided through
     * {@link WebViewMediaIntegrityApiStatusConfig} for using the
     * WebView Integrity API.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#WEBVIEW_MEDIA_INTEGRITY_API_STATUS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.WEBVIEW_MEDIA_INTEGRITY_API_STATUS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setWebViewMediaIntegrityApiStatus(
            @NonNull WebSettings settings,
            @NonNull WebViewMediaIntegrityApiStatusConfig permissionConfig) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.WEBVIEW_MEDIA_INTEGRITY_API_STATUS;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setWebViewMediaIntegrityApiStatus(permissionConfig);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Returns the {@link WebViewMediaIntegrityApiStatusConfig} currently in use.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#WEBVIEW_MEDIA_INTEGRITY_API_STATUS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.WEBVIEW_MEDIA_INTEGRITY_API_STATUS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static @NonNull WebViewMediaIntegrityApiStatusConfig getWebViewMediaIntegrityApiStatus(
            @NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.WEBVIEW_MEDIA_INTEGRITY_API_STATUS;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getWebViewMediaIntegrityApiStatus();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    @IntDef({WEB_AUTHENTICATION_SUPPORT_NONE,
            WEB_AUTHENTICATION_SUPPORT_FOR_APP,
            WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER})
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Retention(RetentionPolicy.SOURCE)
    @interface WebAuthenticationSupport {
    }

    /**
     * The support level that disables WebAuthn requests from WebView.
     * <p>
     * This is the default behavior.
     */
    public static final int WEB_AUTHENTICATION_SUPPORT_NONE =
            WebSettingsBoundaryInterface.WebauthnSupport.NONE;
    /**
     * The support level that allows WebAuthn requests for the app in which the WebView is embedded.
     * See
     * <a href="https://developers.google.com/digital-asset-links">Digital Asset Links</a>
     * to learn how to associate an app with a website.
     */
    public static final int WEB_AUTHENTICATION_SUPPORT_FOR_APP =
            WebSettingsBoundaryInterface.WebauthnSupport.APP;

    /**
     * The support level that allows apps to make WebAuthn calls for any website. See
     * <a href="https://developer.android.com/training/sign-in/privileged-apps">Privileged apps</a>
     * to learn how to make WebAuthn calls for any website.
     */
    public static final int WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER =
            WebSettingsBoundaryInterface.WebauthnSupport.BROWSER;

    /**
     * Sets the support level for the given {@link WebSettings}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param support  The new support level which this WebView will use.
     * @see #WEB_AUTHENTICATION_SUPPORT_NONE
     * @see #WEB_AUTHENTICATION_SUPPORT_FOR_APP
     * @see #WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#WEB_AUTHENTICATION} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.WEB_AUTHENTICATION,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    public static void setWebAuthenticationSupport(@NonNull WebSettings settings,
            @WebAuthenticationSupport int support) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.WEB_AUTHENTICATION;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setWebAuthenticationSupport(support);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Returns the support level for the given {@link WebSettings}
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return the current support level.
     * @see #setWebAuthenticationSupport(WebSettings, int)
     * @see #WEB_AUTHENTICATION_SUPPORT_NONE
     * @see #WEB_AUTHENTICATION_SUPPORT_FOR_APP
     * @see #WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#WEB_AUTHENTICATION} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.WEB_AUTHENTICATION,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @WebAuthenticationSupport
    @UiThread
    public static int getWebAuthenticationSupport(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.WEB_AUTHENTICATION;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getWebAuthenticationSupport();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    @IntDef({SPECULATIVE_LOADING_DISABLED,
            SPECULATIVE_LOADING_PRERENDER_ENABLED})
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Retention(RetentionPolicy.SOURCE)
    @ExperimentalSpeculativeLoading
    @interface SpeculativeLoadingStatus {
    }

    /**
     * Disables all speculative loading tech. See
     * <a href="https://developer.mozilla.org/en-US/docs/Web/Performance/Speculative_loading">this</a> to learn more.
     * <p>
     * This is the default behavior.
     */
    @ExperimentalSpeculativeLoading
    public static final int SPECULATIVE_LOADING_DISABLED =
            WebSettingsBoundaryInterface.SpeculativeLoadingStatus.DISABLED;

    /**
     * Enabled Prerender for this WebSettings, See
     * <a href="https://developer.chrome.com/docs/web-platform/prerender-pages">Prerender</a>
     * to learn more.
     */
    @ExperimentalSpeculativeLoading
    public static final int SPECULATIVE_LOADING_PRERENDER_ENABLED =
            WebSettingsBoundaryInterface.SpeculativeLoadingStatus.PRERENDER_ENABLED;

    /**
     * Denotes that the SpeculativeLoading API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    public @interface ExperimentalSpeculativeLoading {
    }


    /**
     * Sets whether speculative loading status for this {@link WebSettings}.
     * This API is experimental, it may change in the future without notice. Please use accordingly.
     *
     * @param settings                 Settings retrieved from {@link WebView#getSettings()}.
     * @param speculativeLoadingStatus The new status for the speculative loading.
     *                                 It will to be one of {@link SpeculativeLoadingStatus}
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SPECULATIVE_LOADING} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SPECULATIVE_LOADING,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @ExperimentalSpeculativeLoading
    public static void setSpeculativeLoadingStatus(
            @NonNull WebSettings settings, @SpeculativeLoadingStatus int speculativeLoadingStatus) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.SPECULATIVE_LOADING;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setSpeculativeLoadingStatus(speculativeLoadingStatus);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Gets speculative loading status for this {@link WebSettings}.
     * This API is experimental, it may change in the future without notice. Please use accordingly.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return The current status for the speculative loading.
     * It will to be one of {@link SpeculativeLoadingStatus}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SPECULATIVE_LOADING} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SPECULATIVE_LOADING,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @ExperimentalSpeculativeLoading
    public static @SpeculativeLoadingStatus int getSpeculativeLoadingStatus(
            @NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.SPECULATIVE_LOADING;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getSpeculativeLoadingStatus();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Enables <a href="https://developer.chrome.com/blog/back-forward-cache">BackForwardCache</a>
     * for the given {@link WebSettings}.
     *
     * @param settings                Settings retrieved from {@link WebView#getSettings()}.
     * @param backForwardCacheEnabled whether BackForwardCache should be enabled for this
     *                                {@link WebSettings}
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#BACK_FORWARD_CACHE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.BACK_FORWARD_CACHE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setBackForwardCacheEnabled(@NonNull WebSettings settings,
            boolean backForwardCacheEnabled) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.BACK_FORWARD_CACHE;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setBackForwardCacheEnabled(backForwardCacheEnabled);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the current status of BackForwardCache for this {@link WebSettings}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return Whether BackForwardCache is enabled or not.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#BACK_FORWARD_CACHE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.BACK_FORWARD_CACHE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getBackForwardCacheEnabled(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.BACK_FORWARD_CACHE;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getBackForwardCacheEnabled();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Denotes that the SpeculativeLoading API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    public @interface ExperimentalBackForwardCacheSettings {
    }

    /**
     * Get the current {@link BackForwardCacheSettings} for this {@link WebSettings}.
     *
     * <p>
     * The returned {@link BackForwardCacheSettings} object is live; updates to it will
     * be applied to the {@link WebSettings} immediately.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return The current settings for the BackForwardCache.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3} feature is not
     *     supported. This should be checked before use with
     *     {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    @ExperimentalBackForwardCacheSettings
    public static BackForwardCacheSettings getBackForwardCacheSettings(
            @NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3;
        if (feature.isSupportedByWebView()) {
            return new BackForwardCacheSettings(getAdapter(settings));
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Enables <a href="https://w3c.github.io/payment-request/">PaymentRequest</a> for the given
     * {@link WebSettings}.
     *
     * <p>This feature requires adding the following snippet to the {@code AndroidManifest.xml}:
     *
     * <pre class="prettyprint">
     *   &lt;queries&gt;
     *       &lt;intent&gt;
     *           &lt;action android:name="org.chromium.intent.action.PAY"/&gt;
     *       &lt;/intent&gt;
     *       &lt;intent&gt;
     *           &lt;action android:name="org.chromium.intent.action.IS_READY_TO_PAY"/&gt;
     *       &lt;/intent&gt;
     *       &lt;intent&gt;
     *           &lt;action android:name="org.chromium.intent.action.UPDATE_PAYMENT_DETAILS"/&gt;
     *       &lt;/intent&gt;
     *   &lt;/queries&gt;
     * </pre>
     *
     * <p>This is needed to allow WebView to query the device for the user's payment applications
     * that are implemented according to the <a
     * href="https://web.dev/articles/android-payment-apps-developers-guide">Android payment app
     * developers guide</a>.
     *
     * <ul>
     * <li>The {@code org.chromium.intent.action.PAY} intent is necessary to let users <a
     * href="https://web.dev/articles/android-payment-apps-developers-guide
     * #step_3_let_a_customer_make_payment">make
     * payments</a>.
     *
     * <li>The {@code org.chromium.intent.action.IS_READY_TO_PAY} intent is necessary to let the
     * merchant website know if the user is <a
     * href="https://web.dev/articles/android-payment-apps-developers-guide
     * #step_2_let_a_merchant_know_if_a_customer_has_an_enrolled_instrument_that_is_ready_to_pay
     * ">ready
     * to pay</a>.
     *
     * <li>The {@code org.chromium.intent.action.UPDATE_PAYMENT_DETAILS} intent is necessary for
     * payment apps to support <a
     * href="https://web.dev/articles/android-payment-apps-delegation
     * #optional_support_dynamic_flow">updating
     * the price dynamically</a> in response to the user selecting a different shipping address or
     * option.
     * </ul>
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param enabled  Whether
     *                 <a href="https://w3c.github.io/payment-request/">PaymentRequest</a>
     *                 should be enabled
     *                 for this {@link WebSettings}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PAYMENT_REQUEST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.PAYMENT_REQUEST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setPaymentRequestEnabled(@NonNull WebSettings settings, boolean enabled) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.PAYMENT_REQUEST;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setPaymentRequestEnabled(enabled);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the current status of <a href="https://w3c.github.io/payment-request/">PaymentRequest</a>
     * for the given {@link WebSettings}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return Whether <a href="https://w3c.github.io/payment-request/">PaymentRequest</a> is
     * enabled.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PAYMENT_REQUEST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.PAYMENT_REQUEST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getPaymentRequestEnabled(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.PAYMENT_REQUEST;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getPaymentRequestEnabled();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Enables support for {@code hasEnrolledInstrument()} method in <a
     * href="https://w3c.github.io/payment-request/">PaymentRequest</a> for the given
     * {@link WebSettings}. This only has any effect if
     * {@code WebSettingsCompat.setPaymentRequestEnabled(settings, true)} has been called.
     *
     * <p>
     * When this setting is disabled, the {@code PaymentRequest.hasEnrolledInstrument()} method
     * always returns {@code false}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param enabled  Whether {@code PaymentRequest.hasEnrolledInstrument()} should be enabled
     *                 for this {@link WebSettings}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PAYMENT_REQUEST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.PAYMENT_REQUEST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setHasEnrolledInstrumentEnabled(@NonNull WebSettings settings,
            boolean enabled) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.PAYMENT_REQUEST;
        if (feature.isSupportedByWebView()) {
            getAdapter(settings).setHasEnrolledInstrumentEnabled(enabled);
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }

    /**
     * Get the current status of {@code hasEnrolledInstrument()} method in <a
     * href="https://w3c.github.io/payment-request/">PaymentRequest</a> for the given
     * {@link WebSettings}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @return Whether {@code PaymentRequest.hasEnrolledInstrument()} is enabled for this
     * {@link WebSettings}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PAYMENT_REQUEST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.PAYMENT_REQUEST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getHasEnrolledInstrumentEnabled(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.PAYMENT_REQUEST;
        if (feature.isSupportedByWebView()) {
            return getAdapter(settings).getHasEnrolledInstrumentEnabled();
        } else {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
    }


    /**
     * This method controls if the relevant {@code Cookie} header will be added to the
     * {@link WebResourceRequest} object passed to
     * {@link WebViewClient#shouldInterceptRequest(WebView, WebResourceRequest)}.
     * It also enables the use of
     * {@link WebResourceResponseCompat#setCookies(List)}, which will
     * otherwise be ignored.
     *
     * <p>Prefer using this method over calling {@link CookieManager} as part of
     * intercepting requests if it is necessary to access cookies, as this approach will provide
     * the correct set of cookies for the request.
     *
     * <p>This method should only be called if
     * {@link WebViewFeature#isFeatureSupported(String)} returns {@code true} for
     * {@link WebViewFeature#COOKIE_INTERCEPT}.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @param enabled  Whether cookie access during request intercept should be enabled.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#COOKIE_INTERCEPT} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.COOKIE_INTERCEPT,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setCookiesIncludedInShouldInterceptRequest(
            @NonNull WebSettings settings, boolean enabled) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.COOKIE_INTERCEPT;
        if (!feature.isSupportedByWebView()) {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
        getAdapter(settings).setCookieAccessForShouldInterceptRequestEnabled(enabled);
    }


    /**
     * Returns whether cookie access during request intercept is enabled.
     *
     * @param settings Settings retrieved from {@link WebView#getSettings()}.
     * @see #setCookiesIncludedInShouldInterceptRequest(WebSettings, boolean)
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#COOKIE_INTERCEPT} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.COOKIE_INTERCEPT,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean areCookiesIncludedInShouldInterceptRequest(
            @NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.COOKIE_INTERCEPT;
        if (!feature.isSupportedByWebView()) {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
        return getAdapter(settings).getCookieAccessForShouldInterceptRequestEnabled();
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @IntDef(
            flag = true,
            value = {
                    HyperlinkContextMenuItems.DISABLED,
                    HyperlinkContextMenuItems.COPY_LINK_ADDRESS,
                    HyperlinkContextMenuItems.COPY_LINK_TEXT,
                    HyperlinkContextMenuItems.OPEN_LINK
            })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.METHOD, ElementType.PARAMETER, ElementType.FIELD,
            ElementType.LOCAL_VARIABLE})
    public @interface HyperlinkContextMenuItems {
        int DISABLED = 0;
        int COPY_LINK_ADDRESS = 1; // 2^0
        int COPY_LINK_TEXT = 1 << 1; // 2^1
        int OPEN_LINK = 1 << 2; // 2^2
    }

    /**
     * Sets which items appear in the context menu when a user long-presses a hyperlink.
     * The default value is HyperlinkContextMenuItems.DISABLED which means no menu is shown.
     *
     * <p>The items are specified using bitwise flags. You can combine multiple items using
     * the bitwise OR operator (`|`). For example:
     *
     * <pre>{@code
     * // Show only "Copy link address" and "Open link".
     * webSettings.setHyperlinkContextMenuItems(
     *     WebSettingsCompat.HyperlinkContextMenuItems.COPY_LINK_ADDRESS |
     *         WebSettingsCompat.HyperlinkContextMenuItems.OPEN_LINK);
     * }</pre>
     *
     * @param settings           The {@link WebSettings} instance to apply the items to.
     * @param hyperlinkMenuItems A bitwise combination of the following flags:
     *                           <ul>
     *                             <li>{@link HyperlinkContextMenuItems#COPY_LINK_ADDRESS}</li>
     *                             <li>{@link HyperlinkContextMenuItems#COPY_LINK_TEXT}</li>
     *                             <li>{@link HyperlinkContextMenuItems#OPEN_LINK}</li>
     *                           </ul>
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#HYPERLINK_CONTEXT_MENU_ITEMS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.HYPERLINK_CONTEXT_MENU_ITEMS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setHyperlinkContextMenuItems(@NonNull WebSettings settings,
            @HyperlinkContextMenuItems int hyperlinkMenuItems) {
        final ApiFeature.NoFramework feature =
                WebViewFeatureInternal.HYPERLINK_CONTEXT_MENU_ITEMS;
        if (!feature.isSupportedByWebView()) {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
        getAdapter(settings).setHyperlinkContextMenuItems(hyperlinkMenuItems);
    }

    /**
     * Sets whether the WebView will download a Favicon upon
     * navigation.
     * <p>
     * If you are not using Favicons it is recommended to set this
     * to false to save resources like bandwidth and memory.
     *
     * @param settings The WebSettings object to update
     * @param enabled Whether downloading favicons is enabled
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#DOWNLOAD_FAVICONS_ENABLED} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.DOWNLOAD_FAVICONS_ENABLED,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static void setDownloadFaviconsEnabled(@NonNull WebSettings settings, boolean enabled) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.DOWNLOAD_FAVICONS_ENABLED;
        if (!feature.isSupportedByWebView()) {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
        getAdapter(settings).setDownloadFaviconsEnabled(enabled);
    }

    /**
     * Returns whether the WebView will download a Favicon upon
     * navigation.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#DOWNLOAD_FAVICONS_ENABLED} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.DOWNLOAD_FAVICONS_ENABLED,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    public static boolean getDownloadFaviconsEnabled(@NonNull WebSettings settings) {
        final ApiFeature.NoFramework feature = WebViewFeatureInternal.DOWNLOAD_FAVICONS_ENABLED;
        if (!feature.isSupportedByWebView()) {
            throw WebViewFeatureInternal.getUnsupportedOperationException();
        }
        return getAdapter(settings).getDownloadFaviconsEnabled();
    }


    private static WebSettingsAdapter getAdapter(WebSettings settings) {
        try {
            return WebViewGlueCommunicator.getCompatConverter().convertSettings(settings);
        } catch (ClassCastException e) {
            if (Build.VERSION.SDK_INT == 30
                    && "android.webkit.WebSettingsWrapper"
                    .equals(settings.getClass().getCanonicalName())) {
                // This is a patch for a bug observed only on OnePlus devices running SDK version
                // 30. See https://crbug.com/388824130.
                Log.e(
                        TAG,
                        "Error converting WebSettings to Chrome implementation. All AndroidX method"
                                + " calls on this WebSettings instance will be no-op calls. See"
                                + " https://crbug.com/388824130 for more info.",
                        e);
                return new WebSettingsNoOpAdapter();
            }
            throw e;
        }
    }
}

