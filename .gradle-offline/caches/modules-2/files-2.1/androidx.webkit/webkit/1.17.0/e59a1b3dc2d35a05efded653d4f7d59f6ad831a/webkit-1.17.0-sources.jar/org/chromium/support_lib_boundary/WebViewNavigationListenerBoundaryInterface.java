// Copyright 2025 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

package org.chromium.support_lib_boundary;

import org.jspecify.annotations.NullMarked;

import java.lang.reflect.InvocationHandler;

/** Boundary interface for WebViewNavigationListener. */
@NullMarked
public interface WebViewNavigationListenerBoundaryInterface
        extends FeatureFlagHolderBoundaryInterface {
    void onNavigationStarted(/* WebViewNavigation */ InvocationHandler navigation);

    void onNavigationRedirected(/* WebViewNavigation */ InvocationHandler navigation);

    void onNavigationCompleted(/* WebViewNavigation */ InvocationHandler navigation);

    void onPageDeleted(/* WebViewPage */ InvocationHandler page);

    void onPageLoadEventFired(/* WebViewPage */ InvocationHandler page);

    void onPageDOMContentLoadedEventFired(/* WebViewPage */ InvocationHandler page);

    void onFirstContentfulPaint(/* WebViewPage */ InvocationHandler page, long loadTimeUs);

    void onFirstContentfulPaintMillis(
            /* WebViewPage */ InvocationHandler page, long durationMillis);

    void onLargestContentfulPaintMillis(
            /* WebViewPage */ InvocationHandler page, long durationMillis);

    void onPerformanceMarkMillis(
            /* WebViewPage */ InvocationHandler page, String markName, long durationMillis);
}
